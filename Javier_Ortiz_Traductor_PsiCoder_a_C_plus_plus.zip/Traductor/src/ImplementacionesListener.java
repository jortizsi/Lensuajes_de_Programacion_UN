/***
 * Excerpted from "The Definitive ANTLR 4 Reference",
 * published by The Pragmatic Bookshelf.
 * Copyrights apply to this code. It may not be used to create training material,
 * courses, books, articles, and the like. Contact us if you are in doubt.
 * We make no guarantees that this code is fit for any purpose.
 * Visit http://www.pragmaticprogrammer.com/titles/tpantlr2 for more book information.
 ***/
/** Convert short array inits like {1,2,3} to "\u0001\u0002\u0003" */
public class ImplementacionesListener extends PsicoderBaseListener {

    /*

    @Override
    public void enterInit(PsicoderParser.InitContext ctx) {
        System.out.print('"');
    }


    @Override
    public void exitInit(PsicoderParser.InitContext ctx) {
        System.out.print('"');
    }


    @Override
    public void enterValue(PsicoderParser.ValueContext ctx) {
        if(ctx.INT()!=null) {
            // Assumes no nested array initializers
            int value = Integer.valueOf(ctx.INT().getText());
            System.out.printf("\\u%04x", value);
        }
    }
    */





    /** Translate integers to 4-digit hexadecimal strings prefixed with \\u */
    @Override
    public void enterLectura(PsicoderParser.LecturaContext ctx){
            // Assumes no nested array initializer
            System.out.printf("cin>>");
    }


    @Override
    public void exitLectura(PsicoderParser.LecturaContext ctx){
        // Assumes no nested array initializer
        System.out.printf(";\n");
    }





    //

    @Override
    public void enterAtributo_o_variable(PsicoderParser.Atributo_o_variableContext ctx){
        // Assumes no nested array initializer
        String lexema = ctx.ID().getText();
        System.out.printf(lexema);
    }

    @Override
    public void exitAtributo_o_variable(PsicoderParser.Atributo_o_variableContext ctx){
        // Assumes no nested array initialize
    }




    //

    @Override
    public void enterGetters(PsicoderParser.GettersContext ctx){
        // Assumes no nested array initializer
        if(ctx.ID()!=null) {
            String lexema = ctx.ID().getText();
            System.out.printf(".");
            System.out.printf(lexema);
        }
    }

    @Override
    public void exitGetters(PsicoderParser.GettersContext ctx){
        // Assumes no nested array initializer

    }













    @Override
    public void enterImpresion(PsicoderParser.ImpresionContext ctx){
        // Assumes no nested array initializer
        System.out.printf("cout<<");
    }

    @Override
    public void exitImpresion(PsicoderParser.ImpresionContext ctx){
        // Assumes no nested array initializer
        System.out.printf(";\n");
    }




    @Override
    public void enterParametros_impresion_2_a_n(PsicoderParser.Parametros_impresion_2_a_nContext ctx){
        // Assumes no nested array initializer
        System.out.printf("<<");
    }

    @Override
    public void exitParametros_impresion_2_a_n(PsicoderParser.Parametros_impresion_2_a_nContext ctx){
        // Assumes no nested array initializer

    }




    @Override
    public void enterExpresion_entre_parentesis(PsicoderParser.Expresion_entre_parentesisContext ctx){
        // Assumes no nested array initializer
        System.out.printf("(");
    }

    @Override
    public void exitExpresion_entre_parentesis(PsicoderParser.Expresion_entre_parentesisContext ctx){
        // Assumes no nested array initializer
        System.out.printf(")");
    }



    @Override
    public void enterPosible_negacion_o_cambio_de_signo(PsicoderParser.Posible_negacion_o_cambio_de_signoContext ctx) {
        if(ctx.TK_NEG()!=null) {
            // Assumes no nested array initializers
            System.out.printf("!");
        }else if (ctx.TK_MENOS()!=null) {
            // Assumes no nested array initializers
            System.out.printf("-");
        }
    }




    @Override
    public void enterDato(PsicoderParser.DatoContext ctx){
        // Assumes no nested array initializer
        String lexema = "";
        if(ctx.TK_CADENA()!=null) {
            lexema = ctx.TK_CADENA().getText();
        }else if(ctx.TK_ENTERO()!=null) {
            lexema = ctx.TK_ENTERO().getText();
        }else if(ctx.TK_REAL()!=null) {
        lexema = ctx.TK_REAL().getText();
        }else if(ctx.TK_CARACTER()!=null) {
            lexema = ctx.TK_CARACTER().getText();
        }else if(ctx.FALSO()!=null) {
            lexema = "false";
        }else if(ctx.VERDADERO()!=null) {
            lexema = "true";
        }

        System.out.printf(lexema);
    }


    /*

     operacion: TK_MAS
          | TK_MENOS
          | TK_MULT
          | TK_DIV
          | TK_MOD
          | TK_MENOR
          | TK_MAYOR
          | TK_MENOR_IGUAL
          | TK_MAYOR_IGUAL
          | TK_IGUAL
          | TK_DIF
          | TK_O
          | TK_Y;
     */

    @Override
    public void enterOperacion(PsicoderParser.OperacionContext ctx){
        // Assumes no nested array initializer
        String lexema = "";
        if(ctx.TK_MENOS()!=null) {
            lexema = ctx.TK_MENOS().getText();
        }else if(ctx.TK_MAS()!=null) {
            lexema = ctx.TK_MAS().getText();
        } else if(ctx.TK_MULT()!=null) {
            lexema = ctx.TK_MULT().getText();
        }else if(ctx.TK_DIV()!=null) {
            lexema = ctx.TK_DIV().getText();
        }else if(ctx.TK_MOD()!=null) {
            lexema = "%%";
        }else if(ctx.TK_MENOR()!=null) {
            lexema = ctx.TK_MENOR().getText();
        }else if(ctx.TK_MAYOR()!=null) {
            lexema = ctx.TK_MAYOR().getText();
        }else if(ctx.TK_MENOR_IGUAL()!=null) {
            lexema = ctx.TK_MENOR_IGUAL().getText();
        }else if(ctx.TK_MAYOR_IGUAL()!=null) {
            lexema = ctx.TK_MAYOR_IGUAL().getText();
        }else if(ctx.TK_IGUAL()!=null) {
            lexema = ctx.TK_IGUAL().getText();
        }else if(ctx.TK_DIF()!=null) {
            lexema = ctx.TK_DIF().getText();
        }else if(ctx.TK_O()!=null) {
            lexema = ctx.TK_O().getText();
        }else if(ctx.TK_Y()!=null) {
            lexema = ctx.TK_Y().getText();
        }

        System.out.printf(lexema);
    }


    @Override
    public void enterElemento_para_operacion(PsicoderParser.Elemento_para_operacionContext ctx) {
        if(ctx.ID()!=null) {
            // Assumes no nested array initializers
            System.out.printf(ctx.ID().getText());
        }
    }




    @Override
    public void enterPosible_funcion_o_atributo(PsicoderParser.Posible_funcion_o_atributoContext ctx) {
        if(ctx.TK_PUNTO()!=null && ctx.ID()!=null) {
            // Assumes no nested array initializers
            System.out.printf(ctx.TK_PUNTO().getText());
            System.out.printf(ctx.ID().getText());
        }
    }




    @Override
    public void enterLlamada_a_funcion(PsicoderParser.Llamada_a_funcionContext ctx)  {
            System.out.printf("(");
    }


    @Override
    public void exitLlamada_a_funcion(PsicoderParser.Llamada_a_funcionContext ctx)  {
        System.out.printf(")");
    }





    @Override
    public void enterParametros_llamada_a_funcion_2_a_n(PsicoderParser.Parametros_llamada_a_funcion_2_a_nContext ctx)  {
        System.out.printf(",");
    }




    @Override
    public void enterParametro_llamada_a_funcion(PsicoderParser.Parametro_llamada_a_funcionContext ctx)  {
        if(ctx.ID()!=null) {
            System.out.printf(ctx.ID().getText());
        }
    }



    @Override
    public void exitTipo(PsicoderParser.TipoContext ctx)  {
        if(ctx.ENTERO()!=null) {
            System.out.printf("int ");
        }else if(ctx.REAL()!=null) {
            System.out.printf("double ");
        }else if(ctx.CARACTER()!=null) {
            System.out.printf("char ");
        }else if(ctx.CADENA()!=null) {
            System.out.printf("string ");
        }else if(ctx.BOOLEANO()!=null) {
            System.out.printf("bool ");
        }
    }



    @Override
    public void enterEstructura(PsicoderParser.EstructuraContext ctx)   {
        if(ctx.ESTRUCTURA()!=null) {
            System.out.printf("class ");
        }

        if(ctx.ID()!=null) {
            System.out.printf(ctx.ID().getText() + " {\npublic:\n");
        }
    }


    @Override
    public void exitEstructura(PsicoderParser.EstructuraContext ctx)   {
            System.out.printf("};\n\n");
    }

    @Override
    public void enterDeclaracion_instancia_objeto(PsicoderParser.Declaracion_instancia_objetoContext ctx) {
        if(ctx.ID(0)!=null) {
            System.out.printf(ctx.ID(0).getText() + " "); //Nombre de la clase
        }

        if(ctx.ID(1)!=null) {
            System.out.printf(ctx.ID(1).getText()); //Nombre del objeto instanciado
        }

        if(ctx.TK_PYC()!=null) {
            System.out.printf(ctx.TK_PYC().getText() + "\n");
        }

    }



    @Override
    public void enterDeclaracion(PsicoderParser.DeclaracionContext ctx) {
        if(ctx.ID()!=null) {
            System.out.printf(ctx.ID().getText());
        }
    }

    @Override
    public void exitDeclaracion(PsicoderParser.DeclaracionContext ctx) {
        if(ctx.TK_PYC()!=null) {
            System.out.printf(ctx.TK_PYC().getText() + "\n");
        }
    }


    @Override
    public void enterVariables_2_a_n(PsicoderParser.Variables_2_a_nContext ctx) {
        if(ctx.TK_COMA()!=null) {
            System.out.printf(ctx.TK_COMA().getText());
        }
        if(ctx.ID()!=null) {
            System.out.printf(ctx.ID().getText());
        }
    }


    @Override
    public void enterInicializacion_variable(PsicoderParser.Inicializacion_variableContext ctx) {
        if(ctx.TK_ASIG()!=null) {
            System.out.printf(" " + ctx.TK_ASIG().getText() + " ");
        }
    }




    @Override
    public void enterAsignacion(PsicoderParser.AsignacionContext ctx) {
        if(ctx.TK_ASIG()!=null) {
            System.out.printf(" " + ctx.TK_ASIG().getText() + " ");
        }
    }

    @Override
    public void exitAsignacion(PsicoderParser.AsignacionContext ctx) {

    }




    @Override
    public void enterGestor_id(PsicoderParser.Gestor_idContext ctx) {
        if(ctx.ID()!=null) {
            System.out.printf(ctx.ID().getText());
        }
    }

    @Override
    public void
    enterVariable_o_objeto_o_funcion(PsicoderParser.Variable_o_objeto_o_funcionContext ctx) {
        if(ctx.TK_PUNTO()!=null) {
            System.out.printf("."+ ctx.ID().getText());
        }else if(ctx.ID()!=null){
            System.out.printf(" " + ctx.ID().getText());
        }
    }


    @Override
    public void
    exitVariable_o_objeto_o_funcion(PsicoderParser.Variable_o_objeto_o_funcionContext ctx) {
        if(ctx.TK_PYC()!=null) {
            System.out.printf(";\n");
        }

    }






    @Override
    public void enterCondicional(PsicoderParser.CondicionalContext ctx) {
        System.out.printf("if");
    }

    @Override
    public void exitCondicional(PsicoderParser.CondicionalContext ctx) {
        System.out.printf("}\n");
    }

    @Override
    public void enterCondicion_a_evaluar(PsicoderParser.Condicion_a_evaluarContext ctx) {
        System.out.printf("(");
    }

    @Override
    public void exitCondicion_a_evaluar(PsicoderParser.Condicion_a_evaluarContext ctx) {
        System.out.printf("){\n");
    }

    @Override
    public void enterAlternativa(PsicoderParser.AlternativaContext ctx) {
        System.out.printf("}else{\n");
    }

    @Override
    public void exitAlternativa(PsicoderParser.AlternativaContext ctx) {

    }

    @Override
    public void enterAccion(PsicoderParser.AccionContext ctx) {
        if(ctx.ROMPER()!=null) {
            System.out.printf("break;\n");
        }
    }


    @Override
    public void enterCiclo_para(PsicoderParser.Ciclo_paraContext ctx) {
        System.out.printf("for(");
    }

    @Override
    public void exitCiclo_para(PsicoderParser.Ciclo_paraContext ctx) {
        System.out.printf("};\n");
    }

    @Override
    public void enterInicializacion_ciclo_para(PsicoderParser.Inicializacion_ciclo_paraContext ctx) {
        if(ctx.ENTERO()!=null) {
            System.out.printf("int " + ctx.ID().getText()+ " = " +  ctx.TK_ENTERO().getText() + ";");
        }else{
            System.out.printf(ctx.ID().getText()  + " = " +  ctx.TK_ENTERO() + ";");
        }
    }


    @Override
    public void exitInicializacion_ciclo_para(PsicoderParser.Inicializacion_ciclo_paraContext ctx) {
        if(ctx.ENTERO()!=null) {
            System.out.printf(";"+ctx.ID().getText() + " += ");
        }else{
            System.out.printf(";"+ctx.ID().getText() + " += ");
        }
    }


    @Override
    public void enterPaso(PsicoderParser.PasoContext ctx) {
        if(ctx.ID()!=null) {
            System.out.printf(ctx.ID().getText() + "){\n");
        }else{
            System.out.printf(ctx.TK_ENTERO().getText() + "){\n");
        }
    }



    @Override
    public void enterCiclo_mientras(PsicoderParser.Ciclo_mientrasContext ctx) {
        System.out.printf("while");
    }

    @Override
    public void exitCiclo_mientras(PsicoderParser.Ciclo_mientrasContext ctx) {
        System.out.printf("}\n");
    }





    @Override
    public void enterCondicion_mientras(PsicoderParser.Condicion_mientrasContext ctx) {
        System.out.printf("(");
    }

    @Override
    public void exitCondicion_mientras(PsicoderParser.Condicion_mientrasContext ctx) {
        System.out.printf("){\n");
    }







    @Override
    public void enterCiclo_hacer_mientras(PsicoderParser.Ciclo_hacer_mientrasContext ctx) {
        System.out.printf("do{\n");
    }


    @Override
    public void enterClausula_mientras(PsicoderParser.Clausula_mientrasContext ctx) {
        System.out.printf("}while");
    }

    @Override
    public void exitClausula_mientras(PsicoderParser.Clausula_mientrasContext ctx) {
        System.out.printf(";\n");
    }


    @Override
    public void enterCondicion_clausula_mientras(PsicoderParser.Condicion_clausula_mientrasContext ctx) {
        System.out.printf("(");
    }

    @Override
    public void exitCondicion_clausula_mientras(PsicoderParser.Condicion_clausula_mientrasContext ctx) {
        System.out.printf(")");
    }


    @Override
    public void enterAccion_chm(PsicoderParser.Accion_chmContext ctx) {
        if(ctx.ROMPER()!=null) {
            System.out.printf("break;\n");
        }
    }




    @Override
    public void enterComando_seleccion(PsicoderParser.Comando_seleccionContext ctx) {
        System.out.printf("switch("+ ctx.ID().getText()+"){\n");
    }

    @Override
    public void exitComando_seleccion(PsicoderParser.Comando_seleccionContext ctx) {
        System.out.printf("}\n");
    }


    @Override
    public void enterCaso_defecto(PsicoderParser.Caso_defectoContext ctx) {
        System.out.printf("default:\n");
    }

    @Override
    public void enterUno_o_mas_casos(PsicoderParser.Uno_o_mas_casosContext ctx) {
        System.out.printf("case " + ctx.TK_ENTERO().getText()+ ":\n");
    }

    @Override
    public void enterCasos_2_a_n(PsicoderParser.Casos_2_a_nContext ctx) {
        if(ctx.TK_ENTERO()!=null) {
            System.out.printf("case " + ctx.TK_ENTERO().getText() + ":\n");
        }
    }


    @Override
    public void enterRompimiento(PsicoderParser.RompimientoContext ctx) {
        if(ctx.ROMPER()!=null) {
            System.out.printf("break;\n");
        }
    }


    @Override
    public void enterFuncion_principal(PsicoderParser.Funcion_principalContext ctx) {
        System.out.printf("int main() {\n");
    }

    @Override
    public void exitFuncion_principal(PsicoderParser.Funcion_principalContext ctx) {
        System.out.printf("}");
    }


    @Override
    public void enterPrograma_en_psicoder(PsicoderParser.Programa_en_psicoderContext ctx) {
        System.out.printf("#include <iostream>"+"\n"+ "using namespace std;\n\n");
    }


    @Override
    public void enterOperandos_funcion(PsicoderParser.Operandos_funcionContext ctx) {
        System.out.printf(ctx.ID().getText() + "(");
    }

    @Override
    public void exitOperandos_funcion(PsicoderParser.Operandos_funcionContext ctx) {
        System.out.printf("){\n");
    }

    @Override public void enterTipo_salida_funcion(PsicoderParser.Tipo_salida_funcionContext ctx) {
        if(ctx.ID()!=null) {
            System.out.printf(ctx.ID().getText() + " ");
        }
    }

    @Override public void exitFuncion(PsicoderParser.FuncionContext ctx) {
        System.out.printf("}\n\n");
    }


    @Override
    public void enterRetorno_de_la_funcion(PsicoderParser.Retorno_de_la_funcionContext ctx) {
        if(ctx.RETORNAR()!=null) {
            System.out.printf("return ");
        }
    }

    @Override
    public void exitRetorno_de_la_funcion(PsicoderParser.Retorno_de_la_funcionContext ctx) {
        System.out.printf(";\n");
    }


    @Override
    public void exitParametro_i_funcion(PsicoderParser.Parametro_i_funcionContext ctx) {
        System.out.printf(ctx.ID().getText());
    }


    @Override
    public void enterParametros_funcion_2_a_n(PsicoderParser.Parametros_funcion_2_a_nContext ctx) {
        System.out.printf(", ");
    }


}