// Generated from C:/Users/Alejandro Ortiz/IdeaProjects/Traductor/grammar\Psicoder.g4 by ANTLR 4.9.1
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class PsicoderParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.9.1", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		T__0=1, IMPRIMIR=2, BOOLEANO=3, CARACTER=4, ENTERO=5, REAL=6, CADENA=7, 
		SI=8, FIN_SI=9, ENTONCES=10, SI_NO=11, FUNCION=12, RETORNAR=13, FIN_FUNCION=14, 
		ROMPER=15, PARA=16, FIN_PARA=17, ESTRUCTURA=18, FIN_ESTRUCTURA=19, MIENTRAS=20, 
		FIN_MIENTRAS=21, HACER=22, SELECCIONAR=23, ENTRE=24, FIN_SELECCIONAR=25, 
		DEFECTO=26, TK_DOSP=27, CASO=28, TK_CARACTER=29, TK_ENTERO=30, TK_CADENA=31, 
		TK_REAL=32, TK_NEG=33, FUNCION_PRINCIPAL=34, FIN_PRINCIPAL=35, TK_PAR_IZQ=36, 
		TK_PAR_DER=37, TK_PYC=38, TK_PUNTO=39, TK_COMA=40, TK_ASIG=41, TK_MAS=42, 
		TK_MENOS=43, TK_MULT=44, TK_DIV=45, TK_MOD=46, TK_MENOR=47, TK_MAYOR=48, 
		TK_MENOR_IGUAL=49, TK_MAYOR_IGUAL=50, TK_IGUAL=51, TK_DIF=52, TK_O=53, 
		TK_Y=54, VERDADERO=55, FALSO=56, INT=57, WS=58, ID=59, COMENTARIO=60, 
		COMENTARIO_UNICA_LINEA=61;
	public static final int
		RULE_init = 0, RULE_lectura = 1, RULE_atributo_o_variable = 2, RULE_getters = 3, 
		RULE_impresion = 4, RULE_parametros_impresion = 5, RULE_parametros_impresion_2_a_n = 6, 
		RULE_parametro_1_impresion = 7, RULE_expresion_entre_parentesis = 8, RULE_expresion = 9, 
		RULE_expresion_2_a_n = 10, RULE_elemento_para_operacion = 11, RULE_posible_funcion_o_atributo = 12, 
		RULE_posible_negacion_o_cambio_de_signo = 13, RULE_operacion = 14, RULE_dato = 15, 
		RULE_funcion = 16, RULE_retorno_de_la_funcion = 17, RULE_operandos_funcion = 18, 
		RULE_parametro_i_funcion = 19, RULE_parametros_funcion = 20, RULE_parametros_funcion_2_a_n = 21, 
		RULE_llamada_a_funcion = 22, RULE_parametros_llamada_a_funcion = 23, RULE_parametros_llamada_a_funcion_2_a_n = 24, 
		RULE_parametro_llamada_a_funcion = 25, RULE_acciones_cuerpo_funcion = 26, 
		RULE_tipo_salida_funcion = 27, RULE_tipo = 28, RULE_estructura = 29, RULE_declaraciones_1_a_n = 30, 
		RULE_declaracion_instancia_objeto = 31, RULE_declaracion = 32, RULE_variables_2_a_n = 33, 
		RULE_inicializacion_variable = 34, RULE_asignacion = 35, RULE_gestor_id = 36, 
		RULE_variable_o_objeto_o_funcion = 37, RULE_condicional = 38, RULE_condicion_a_evaluar = 39, 
		RULE_alternativa = 40, RULE_acciones_condicional = 41, RULE_accion = 42, 
		RULE_ciclo_para = 43, RULE_inicializacion_ciclo_para = 44, RULE_paso = 45, 
		RULE_acciones_ciclo_para = 46, RULE_ciclo_mientras = 47, RULE_condicion_mientras = 48, 
		RULE_acciones_mientras = 49, RULE_ciclo_hacer_mientras = 50, RULE_acciones_hacer_mientras = 51, 
		RULE_clausula_mientras = 52, RULE_condicion_clausula_mientras = 53, RULE_accion_chm = 54, 
		RULE_comando_seleccion = 55, RULE_casos = 56, RULE_caso_defecto = 57, 
		RULE_uno_o_mas_casos = 58, RULE_casos_2_a_n = 59, RULE_rompimiento = 60, 
		RULE_acciones_comando_seleccion = 61, RULE_accion_seleccion = 62, RULE_estructuras_y_funciones = 63, 
		RULE_estructura_o_funcion = 64, RULE_funcion_principal = 65, RULE_acciones_funcion_principal = 66, 
		RULE_programa_en_psicoder = 67;
	private static String[] makeRuleNames() {
		return new String[] {
			"init", "lectura", "atributo_o_variable", "getters", "impresion", "parametros_impresion", 
			"parametros_impresion_2_a_n", "parametro_1_impresion", "expresion_entre_parentesis", 
			"expresion", "expresion_2_a_n", "elemento_para_operacion", "posible_funcion_o_atributo", 
			"posible_negacion_o_cambio_de_signo", "operacion", "dato", "funcion", 
			"retorno_de_la_funcion", "operandos_funcion", "parametro_i_funcion", 
			"parametros_funcion", "parametros_funcion_2_a_n", "llamada_a_funcion", 
			"parametros_llamada_a_funcion", "parametros_llamada_a_funcion_2_a_n", 
			"parametro_llamada_a_funcion", "acciones_cuerpo_funcion", "tipo_salida_funcion", 
			"tipo", "estructura", "declaraciones_1_a_n", "declaracion_instancia_objeto", 
			"declaracion", "variables_2_a_n", "inicializacion_variable", "asignacion", 
			"gestor_id", "variable_o_objeto_o_funcion", "condicional", "condicion_a_evaluar", 
			"alternativa", "acciones_condicional", "accion", "ciclo_para", "inicializacion_ciclo_para", 
			"paso", "acciones_ciclo_para", "ciclo_mientras", "condicion_mientras", 
			"acciones_mientras", "ciclo_hacer_mientras", "acciones_hacer_mientras", 
			"clausula_mientras", "condicion_clausula_mientras", "accion_chm", "comando_seleccion", 
			"casos", "caso_defecto", "uno_o_mas_casos", "casos_2_a_n", "rompimiento", 
			"acciones_comando_seleccion", "accion_seleccion", "estructuras_y_funciones", 
			"estructura_o_funcion", "funcion_principal", "acciones_funcion_principal", 
			"programa_en_psicoder"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, "'leer'", "'imprimir'", "'booleano'", "'caracter'", "'entero'", 
			"'real'", "'cadena'", "'si'", "'fin_si'", "'entonces'", "'si_no'", "'funcion'", 
			"'retornar'", "'fin_funcion'", "'romper'", "'para'", "'fin_para'", "'estructura'", 
			"'fin_estructura'", "'mientras'", "'fin_mientras'", "'hacer'", "'seleccionar'", 
			"'entre'", "'fin_seleccionar'", "'defecto'", "':'", "'caso'", null, null, 
			null, null, "'!'", "'funcion_principal'", "'fin_principal'", "'('", "')'", 
			"';'", "'.'", "','", "'='", "'+'", "'-'", "'*'", "'/'", "'%'", "'<'", 
			"'>'", "'<='", "'>='", "'=='", "'!='", "'||'", "'&&'", "'verdadero'", 
			"'falso'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, null, "IMPRIMIR", "BOOLEANO", "CARACTER", "ENTERO", "REAL", "CADENA", 
			"SI", "FIN_SI", "ENTONCES", "SI_NO", "FUNCION", "RETORNAR", "FIN_FUNCION", 
			"ROMPER", "PARA", "FIN_PARA", "ESTRUCTURA", "FIN_ESTRUCTURA", "MIENTRAS", 
			"FIN_MIENTRAS", "HACER", "SELECCIONAR", "ENTRE", "FIN_SELECCIONAR", "DEFECTO", 
			"TK_DOSP", "CASO", "TK_CARACTER", "TK_ENTERO", "TK_CADENA", "TK_REAL", 
			"TK_NEG", "FUNCION_PRINCIPAL", "FIN_PRINCIPAL", "TK_PAR_IZQ", "TK_PAR_DER", 
			"TK_PYC", "TK_PUNTO", "TK_COMA", "TK_ASIG", "TK_MAS", "TK_MENOS", "TK_MULT", 
			"TK_DIV", "TK_MOD", "TK_MENOR", "TK_MAYOR", "TK_MENOR_IGUAL", "TK_MAYOR_IGUAL", 
			"TK_IGUAL", "TK_DIF", "TK_O", "TK_Y", "VERDADERO", "FALSO", "INT", "WS", 
			"ID", "COMENTARIO", "COMENTARIO_UNICA_LINEA"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "Psicoder.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public PsicoderParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	public static class InitContext extends ParserRuleContext {
		public Programa_en_psicoderContext programa_en_psicoder() {
			return getRuleContext(Programa_en_psicoderContext.class,0);
		}
		public InitContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_init; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterInit(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitInit(this);
		}
	}

	public final InitContext init() throws RecognitionException {
		InitContext _localctx = new InitContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_init);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(136);
			programa_en_psicoder();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class LecturaContext extends ParserRuleContext {
		public TerminalNode TK_PAR_IZQ() { return getToken(PsicoderParser.TK_PAR_IZQ, 0); }
		public Atributo_o_variableContext atributo_o_variable() {
			return getRuleContext(Atributo_o_variableContext.class,0);
		}
		public TerminalNode TK_PAR_DER() { return getToken(PsicoderParser.TK_PAR_DER, 0); }
		public TerminalNode TK_PYC() { return getToken(PsicoderParser.TK_PYC, 0); }
		public LecturaContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_lectura; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterLectura(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitLectura(this);
		}
	}

	public final LecturaContext lectura() throws RecognitionException {
		LecturaContext _localctx = new LecturaContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_lectura);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(138);
			match(T__0);
			setState(139);
			match(TK_PAR_IZQ);
			setState(140);
			atributo_o_variable();
			setState(141);
			match(TK_PAR_DER);
			setState(142);
			match(TK_PYC);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Atributo_o_variableContext extends ParserRuleContext {
		public TerminalNode ID() { return getToken(PsicoderParser.ID, 0); }
		public GettersContext getters() {
			return getRuleContext(GettersContext.class,0);
		}
		public Atributo_o_variableContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_atributo_o_variable; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterAtributo_o_variable(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitAtributo_o_variable(this);
		}
	}

	public final Atributo_o_variableContext atributo_o_variable() throws RecognitionException {
		Atributo_o_variableContext _localctx = new Atributo_o_variableContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_atributo_o_variable);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(144);
			match(ID);
			setState(146);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==TK_PUNTO) {
				{
				setState(145);
				getters();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class GettersContext extends ParserRuleContext {
		public TerminalNode TK_PUNTO() { return getToken(PsicoderParser.TK_PUNTO, 0); }
		public TerminalNode ID() { return getToken(PsicoderParser.ID, 0); }
		public GettersContext getters() {
			return getRuleContext(GettersContext.class,0);
		}
		public GettersContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_getters; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterGetters(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitGetters(this);
		}
	}

	public final GettersContext getters() throws RecognitionException {
		GettersContext _localctx = new GettersContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_getters);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(148);
			match(TK_PUNTO);
			setState(149);
			match(ID);
			setState(151);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==TK_PUNTO) {
				{
				setState(150);
				getters();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ImpresionContext extends ParserRuleContext {
		public TerminalNode IMPRIMIR() { return getToken(PsicoderParser.IMPRIMIR, 0); }
		public TerminalNode TK_PAR_IZQ() { return getToken(PsicoderParser.TK_PAR_IZQ, 0); }
		public Parametros_impresionContext parametros_impresion() {
			return getRuleContext(Parametros_impresionContext.class,0);
		}
		public TerminalNode TK_PAR_DER() { return getToken(PsicoderParser.TK_PAR_DER, 0); }
		public TerminalNode TK_PYC() { return getToken(PsicoderParser.TK_PYC, 0); }
		public ImpresionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_impresion; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterImpresion(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitImpresion(this);
		}
	}

	public final ImpresionContext impresion() throws RecognitionException {
		ImpresionContext _localctx = new ImpresionContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_impresion);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(153);
			match(IMPRIMIR);
			setState(154);
			match(TK_PAR_IZQ);
			setState(155);
			parametros_impresion();
			setState(156);
			match(TK_PAR_DER);
			setState(157);
			match(TK_PYC);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Parametros_impresionContext extends ParserRuleContext {
		public Parametro_1_impresionContext parametro_1_impresion() {
			return getRuleContext(Parametro_1_impresionContext.class,0);
		}
		public Parametros_impresion_2_a_nContext parametros_impresion_2_a_n() {
			return getRuleContext(Parametros_impresion_2_a_nContext.class,0);
		}
		public Parametros_impresionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_parametros_impresion; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterParametros_impresion(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitParametros_impresion(this);
		}
	}

	public final Parametros_impresionContext parametros_impresion() throws RecognitionException {
		Parametros_impresionContext _localctx = new Parametros_impresionContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_parametros_impresion);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(159);
			parametro_1_impresion();
			setState(161);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==TK_COMA) {
				{
				setState(160);
				parametros_impresion_2_a_n();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Parametros_impresion_2_a_nContext extends ParserRuleContext {
		public TerminalNode TK_COMA() { return getToken(PsicoderParser.TK_COMA, 0); }
		public ExpresionContext expresion() {
			return getRuleContext(ExpresionContext.class,0);
		}
		public Parametros_impresion_2_a_nContext parametros_impresion_2_a_n() {
			return getRuleContext(Parametros_impresion_2_a_nContext.class,0);
		}
		public Parametros_impresion_2_a_nContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_parametros_impresion_2_a_n; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterParametros_impresion_2_a_n(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitParametros_impresion_2_a_n(this);
		}
	}

	public final Parametros_impresion_2_a_nContext parametros_impresion_2_a_n() throws RecognitionException {
		Parametros_impresion_2_a_nContext _localctx = new Parametros_impresion_2_a_nContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_parametros_impresion_2_a_n);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(163);
			match(TK_COMA);
			setState(164);
			expresion();
			setState(166);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==TK_COMA) {
				{
				setState(165);
				parametros_impresion_2_a_n();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Parametro_1_impresionContext extends ParserRuleContext {
		public ExpresionContext expresion() {
			return getRuleContext(ExpresionContext.class,0);
		}
		public Parametro_1_impresionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_parametro_1_impresion; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterParametro_1_impresion(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitParametro_1_impresion(this);
		}
	}

	public final Parametro_1_impresionContext parametro_1_impresion() throws RecognitionException {
		Parametro_1_impresionContext _localctx = new Parametro_1_impresionContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_parametro_1_impresion);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(168);
			expresion();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Expresion_entre_parentesisContext extends ParserRuleContext {
		public TerminalNode TK_PAR_IZQ() { return getToken(PsicoderParser.TK_PAR_IZQ, 0); }
		public ExpresionContext expresion() {
			return getRuleContext(ExpresionContext.class,0);
		}
		public TerminalNode TK_PAR_DER() { return getToken(PsicoderParser.TK_PAR_DER, 0); }
		public Expresion_entre_parentesisContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_expresion_entre_parentesis; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterExpresion_entre_parentesis(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitExpresion_entre_parentesis(this);
		}
	}

	public final Expresion_entre_parentesisContext expresion_entre_parentesis() throws RecognitionException {
		Expresion_entre_parentesisContext _localctx = new Expresion_entre_parentesisContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_expresion_entre_parentesis);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(170);
			match(TK_PAR_IZQ);
			setState(171);
			expresion();
			setState(172);
			match(TK_PAR_DER);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ExpresionContext extends ParserRuleContext {
		public Elemento_para_operacionContext elemento_para_operacion() {
			return getRuleContext(Elemento_para_operacionContext.class,0);
		}
		public Posible_negacion_o_cambio_de_signoContext posible_negacion_o_cambio_de_signo() {
			return getRuleContext(Posible_negacion_o_cambio_de_signoContext.class,0);
		}
		public Expresion_2_a_nContext expresion_2_a_n() {
			return getRuleContext(Expresion_2_a_nContext.class,0);
		}
		public ExpresionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_expresion; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterExpresion(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitExpresion(this);
		}
	}

	public final ExpresionContext expresion() throws RecognitionException {
		ExpresionContext _localctx = new ExpresionContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_expresion);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(175);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==TK_NEG || _la==TK_MENOS) {
				{
				setState(174);
				posible_negacion_o_cambio_de_signo();
				}
			}

			setState(177);
			elemento_para_operacion();
			setState(179);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << TK_MAS) | (1L << TK_MENOS) | (1L << TK_MULT) | (1L << TK_DIV) | (1L << TK_MOD) | (1L << TK_MENOR) | (1L << TK_MAYOR) | (1L << TK_MENOR_IGUAL) | (1L << TK_MAYOR_IGUAL) | (1L << TK_IGUAL) | (1L << TK_DIF) | (1L << TK_O) | (1L << TK_Y))) != 0)) {
				{
				setState(178);
				expresion_2_a_n();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Expresion_2_a_nContext extends ParserRuleContext {
		public OperacionContext operacion() {
			return getRuleContext(OperacionContext.class,0);
		}
		public Elemento_para_operacionContext elemento_para_operacion() {
			return getRuleContext(Elemento_para_operacionContext.class,0);
		}
		public Posible_negacion_o_cambio_de_signoContext posible_negacion_o_cambio_de_signo() {
			return getRuleContext(Posible_negacion_o_cambio_de_signoContext.class,0);
		}
		public Expresion_2_a_nContext expresion_2_a_n() {
			return getRuleContext(Expresion_2_a_nContext.class,0);
		}
		public Expresion_2_a_nContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_expresion_2_a_n; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterExpresion_2_a_n(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitExpresion_2_a_n(this);
		}
	}

	public final Expresion_2_a_nContext expresion_2_a_n() throws RecognitionException {
		Expresion_2_a_nContext _localctx = new Expresion_2_a_nContext(_ctx, getState());
		enterRule(_localctx, 20, RULE_expresion_2_a_n);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(181);
			operacion();
			setState(183);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==TK_NEG || _la==TK_MENOS) {
				{
				setState(182);
				posible_negacion_o_cambio_de_signo();
				}
			}

			setState(185);
			elemento_para_operacion();
			setState(187);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << TK_MAS) | (1L << TK_MENOS) | (1L << TK_MULT) | (1L << TK_DIV) | (1L << TK_MOD) | (1L << TK_MENOR) | (1L << TK_MAYOR) | (1L << TK_MENOR_IGUAL) | (1L << TK_MAYOR_IGUAL) | (1L << TK_IGUAL) | (1L << TK_DIF) | (1L << TK_O) | (1L << TK_Y))) != 0)) {
				{
				setState(186);
				expresion_2_a_n();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Elemento_para_operacionContext extends ParserRuleContext {
		public DatoContext dato() {
			return getRuleContext(DatoContext.class,0);
		}
		public TerminalNode ID() { return getToken(PsicoderParser.ID, 0); }
		public Posible_funcion_o_atributoContext posible_funcion_o_atributo() {
			return getRuleContext(Posible_funcion_o_atributoContext.class,0);
		}
		public Expresion_entre_parentesisContext expresion_entre_parentesis() {
			return getRuleContext(Expresion_entre_parentesisContext.class,0);
		}
		public Elemento_para_operacionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_elemento_para_operacion; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterElemento_para_operacion(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitElemento_para_operacion(this);
		}
	}

	public final Elemento_para_operacionContext elemento_para_operacion() throws RecognitionException {
		Elemento_para_operacionContext _localctx = new Elemento_para_operacionContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_elemento_para_operacion);
		int _la;
		try {
			setState(195);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case TK_CARACTER:
			case TK_ENTERO:
			case TK_CADENA:
			case TK_REAL:
			case VERDADERO:
			case FALSO:
				enterOuterAlt(_localctx, 1);
				{
				setState(189);
				dato();
				}
				break;
			case ID:
				enterOuterAlt(_localctx, 2);
				{
				setState(190);
				match(ID);
				setState(192);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==TK_PAR_IZQ || _la==TK_PUNTO) {
					{
					setState(191);
					posible_funcion_o_atributo();
					}
				}

				}
				break;
			case TK_PAR_IZQ:
				enterOuterAlt(_localctx, 3);
				{
				setState(194);
				expresion_entre_parentesis();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Posible_funcion_o_atributoContext extends ParserRuleContext {
		public Llamada_a_funcionContext llamada_a_funcion() {
			return getRuleContext(Llamada_a_funcionContext.class,0);
		}
		public TerminalNode TK_PUNTO() { return getToken(PsicoderParser.TK_PUNTO, 0); }
		public TerminalNode ID() { return getToken(PsicoderParser.ID, 0); }
		public GettersContext getters() {
			return getRuleContext(GettersContext.class,0);
		}
		public Posible_funcion_o_atributoContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_posible_funcion_o_atributo; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterPosible_funcion_o_atributo(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitPosible_funcion_o_atributo(this);
		}
	}

	public final Posible_funcion_o_atributoContext posible_funcion_o_atributo() throws RecognitionException {
		Posible_funcion_o_atributoContext _localctx = new Posible_funcion_o_atributoContext(_ctx, getState());
		enterRule(_localctx, 24, RULE_posible_funcion_o_atributo);
		int _la;
		try {
			setState(203);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case TK_PAR_IZQ:
				enterOuterAlt(_localctx, 1);
				{
				setState(197);
				llamada_a_funcion();
				}
				break;
			case TK_PUNTO:
				enterOuterAlt(_localctx, 2);
				{
				setState(198);
				match(TK_PUNTO);
				setState(199);
				match(ID);
				setState(201);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==TK_PUNTO) {
					{
					setState(200);
					getters();
					}
				}

				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Posible_negacion_o_cambio_de_signoContext extends ParserRuleContext {
		public TerminalNode TK_NEG() { return getToken(PsicoderParser.TK_NEG, 0); }
		public TerminalNode TK_MENOS() { return getToken(PsicoderParser.TK_MENOS, 0); }
		public Posible_negacion_o_cambio_de_signoContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_posible_negacion_o_cambio_de_signo; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterPosible_negacion_o_cambio_de_signo(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitPosible_negacion_o_cambio_de_signo(this);
		}
	}

	public final Posible_negacion_o_cambio_de_signoContext posible_negacion_o_cambio_de_signo() throws RecognitionException {
		Posible_negacion_o_cambio_de_signoContext _localctx = new Posible_negacion_o_cambio_de_signoContext(_ctx, getState());
		enterRule(_localctx, 26, RULE_posible_negacion_o_cambio_de_signo);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(205);
			_la = _input.LA(1);
			if ( !(_la==TK_NEG || _la==TK_MENOS) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class OperacionContext extends ParserRuleContext {
		public TerminalNode TK_MAS() { return getToken(PsicoderParser.TK_MAS, 0); }
		public TerminalNode TK_MENOS() { return getToken(PsicoderParser.TK_MENOS, 0); }
		public TerminalNode TK_MULT() { return getToken(PsicoderParser.TK_MULT, 0); }
		public TerminalNode TK_DIV() { return getToken(PsicoderParser.TK_DIV, 0); }
		public TerminalNode TK_MOD() { return getToken(PsicoderParser.TK_MOD, 0); }
		public TerminalNode TK_MENOR() { return getToken(PsicoderParser.TK_MENOR, 0); }
		public TerminalNode TK_MAYOR() { return getToken(PsicoderParser.TK_MAYOR, 0); }
		public TerminalNode TK_MENOR_IGUAL() { return getToken(PsicoderParser.TK_MENOR_IGUAL, 0); }
		public TerminalNode TK_MAYOR_IGUAL() { return getToken(PsicoderParser.TK_MAYOR_IGUAL, 0); }
		public TerminalNode TK_IGUAL() { return getToken(PsicoderParser.TK_IGUAL, 0); }
		public TerminalNode TK_DIF() { return getToken(PsicoderParser.TK_DIF, 0); }
		public TerminalNode TK_O() { return getToken(PsicoderParser.TK_O, 0); }
		public TerminalNode TK_Y() { return getToken(PsicoderParser.TK_Y, 0); }
		public OperacionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_operacion; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterOperacion(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitOperacion(this);
		}
	}

	public final OperacionContext operacion() throws RecognitionException {
		OperacionContext _localctx = new OperacionContext(_ctx, getState());
		enterRule(_localctx, 28, RULE_operacion);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(207);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << TK_MAS) | (1L << TK_MENOS) | (1L << TK_MULT) | (1L << TK_DIV) | (1L << TK_MOD) | (1L << TK_MENOR) | (1L << TK_MAYOR) | (1L << TK_MENOR_IGUAL) | (1L << TK_MAYOR_IGUAL) | (1L << TK_IGUAL) | (1L << TK_DIF) | (1L << TK_O) | (1L << TK_Y))) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class DatoContext extends ParserRuleContext {
		public TerminalNode VERDADERO() { return getToken(PsicoderParser.VERDADERO, 0); }
		public TerminalNode FALSO() { return getToken(PsicoderParser.FALSO, 0); }
		public TerminalNode TK_CARACTER() { return getToken(PsicoderParser.TK_CARACTER, 0); }
		public TerminalNode TK_ENTERO() { return getToken(PsicoderParser.TK_ENTERO, 0); }
		public TerminalNode TK_REAL() { return getToken(PsicoderParser.TK_REAL, 0); }
		public TerminalNode TK_CADENA() { return getToken(PsicoderParser.TK_CADENA, 0); }
		public DatoContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_dato; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterDato(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitDato(this);
		}
	}

	public final DatoContext dato() throws RecognitionException {
		DatoContext _localctx = new DatoContext(_ctx, getState());
		enterRule(_localctx, 30, RULE_dato);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(209);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << TK_CARACTER) | (1L << TK_ENTERO) | (1L << TK_CADENA) | (1L << TK_REAL) | (1L << VERDADERO) | (1L << FALSO))) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FuncionContext extends ParserRuleContext {
		public TerminalNode FUNCION() { return getToken(PsicoderParser.FUNCION, 0); }
		public Tipo_salida_funcionContext tipo_salida_funcion() {
			return getRuleContext(Tipo_salida_funcionContext.class,0);
		}
		public Operandos_funcionContext operandos_funcion() {
			return getRuleContext(Operandos_funcionContext.class,0);
		}
		public Retorno_de_la_funcionContext retorno_de_la_funcion() {
			return getRuleContext(Retorno_de_la_funcionContext.class,0);
		}
		public Acciones_cuerpo_funcionContext acciones_cuerpo_funcion() {
			return getRuleContext(Acciones_cuerpo_funcionContext.class,0);
		}
		public FuncionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_funcion; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterFuncion(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitFuncion(this);
		}
	}

	public final FuncionContext funcion() throws RecognitionException {
		FuncionContext _localctx = new FuncionContext(_ctx, getState());
		enterRule(_localctx, 32, RULE_funcion);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(211);
			match(FUNCION);
			setState(212);
			tipo_salida_funcion();
			setState(213);
			operandos_funcion();
			setState(215);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__0) | (1L << IMPRIMIR) | (1L << BOOLEANO) | (1L << CARACTER) | (1L << ENTERO) | (1L << REAL) | (1L << CADENA) | (1L << SI) | (1L << ROMPER) | (1L << PARA) | (1L << MIENTRAS) | (1L << HACER) | (1L << SELECCIONAR) | (1L << ID))) != 0)) {
				{
				setState(214);
				acciones_cuerpo_funcion();
				}
			}

			setState(217);
			retorno_de_la_funcion();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Retorno_de_la_funcionContext extends ParserRuleContext {
		public TerminalNode RETORNAR() { return getToken(PsicoderParser.RETORNAR, 0); }
		public ExpresionContext expresion() {
			return getRuleContext(ExpresionContext.class,0);
		}
		public TerminalNode TK_PYC() { return getToken(PsicoderParser.TK_PYC, 0); }
		public TerminalNode FIN_FUNCION() { return getToken(PsicoderParser.FIN_FUNCION, 0); }
		public Retorno_de_la_funcionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_retorno_de_la_funcion; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterRetorno_de_la_funcion(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitRetorno_de_la_funcion(this);
		}
	}

	public final Retorno_de_la_funcionContext retorno_de_la_funcion() throws RecognitionException {
		Retorno_de_la_funcionContext _localctx = new Retorno_de_la_funcionContext(_ctx, getState());
		enterRule(_localctx, 34, RULE_retorno_de_la_funcion);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(219);
			match(RETORNAR);
			setState(220);
			expresion();
			setState(221);
			match(TK_PYC);
			setState(222);
			match(FIN_FUNCION);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Operandos_funcionContext extends ParserRuleContext {
		public TerminalNode ID() { return getToken(PsicoderParser.ID, 0); }
		public TerminalNode TK_PAR_IZQ() { return getToken(PsicoderParser.TK_PAR_IZQ, 0); }
		public TerminalNode TK_PAR_DER() { return getToken(PsicoderParser.TK_PAR_DER, 0); }
		public TerminalNode HACER() { return getToken(PsicoderParser.HACER, 0); }
		public Parametros_funcionContext parametros_funcion() {
			return getRuleContext(Parametros_funcionContext.class,0);
		}
		public Operandos_funcionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_operandos_funcion; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterOperandos_funcion(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitOperandos_funcion(this);
		}
	}

	public final Operandos_funcionContext operandos_funcion() throws RecognitionException {
		Operandos_funcionContext _localctx = new Operandos_funcionContext(_ctx, getState());
		enterRule(_localctx, 36, RULE_operandos_funcion);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(224);
			match(ID);
			setState(225);
			match(TK_PAR_IZQ);
			setState(227);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << BOOLEANO) | (1L << CARACTER) | (1L << ENTERO) | (1L << REAL) | (1L << CADENA) | (1L << ID))) != 0)) {
				{
				setState(226);
				parametros_funcion();
				}
			}

			setState(229);
			match(TK_PAR_DER);
			setState(230);
			match(HACER);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Parametro_i_funcionContext extends ParserRuleContext {
		public Tipo_salida_funcionContext tipo_salida_funcion() {
			return getRuleContext(Tipo_salida_funcionContext.class,0);
		}
		public TerminalNode ID() { return getToken(PsicoderParser.ID, 0); }
		public Parametro_i_funcionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_parametro_i_funcion; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterParametro_i_funcion(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitParametro_i_funcion(this);
		}
	}

	public final Parametro_i_funcionContext parametro_i_funcion() throws RecognitionException {
		Parametro_i_funcionContext _localctx = new Parametro_i_funcionContext(_ctx, getState());
		enterRule(_localctx, 38, RULE_parametro_i_funcion);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(232);
			tipo_salida_funcion();
			setState(233);
			match(ID);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Parametros_funcionContext extends ParserRuleContext {
		public Parametro_i_funcionContext parametro_i_funcion() {
			return getRuleContext(Parametro_i_funcionContext.class,0);
		}
		public Parametros_funcion_2_a_nContext parametros_funcion_2_a_n() {
			return getRuleContext(Parametros_funcion_2_a_nContext.class,0);
		}
		public Parametros_funcionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_parametros_funcion; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterParametros_funcion(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitParametros_funcion(this);
		}
	}

	public final Parametros_funcionContext parametros_funcion() throws RecognitionException {
		Parametros_funcionContext _localctx = new Parametros_funcionContext(_ctx, getState());
		enterRule(_localctx, 40, RULE_parametros_funcion);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(235);
			parametro_i_funcion();
			setState(237);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==TK_COMA) {
				{
				setState(236);
				parametros_funcion_2_a_n();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Parametros_funcion_2_a_nContext extends ParserRuleContext {
		public TerminalNode TK_COMA() { return getToken(PsicoderParser.TK_COMA, 0); }
		public Parametro_i_funcionContext parametro_i_funcion() {
			return getRuleContext(Parametro_i_funcionContext.class,0);
		}
		public Parametros_funcion_2_a_nContext parametros_funcion_2_a_n() {
			return getRuleContext(Parametros_funcion_2_a_nContext.class,0);
		}
		public Parametros_funcion_2_a_nContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_parametros_funcion_2_a_n; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterParametros_funcion_2_a_n(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitParametros_funcion_2_a_n(this);
		}
	}

	public final Parametros_funcion_2_a_nContext parametros_funcion_2_a_n() throws RecognitionException {
		Parametros_funcion_2_a_nContext _localctx = new Parametros_funcion_2_a_nContext(_ctx, getState());
		enterRule(_localctx, 42, RULE_parametros_funcion_2_a_n);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(239);
			match(TK_COMA);
			setState(240);
			parametro_i_funcion();
			setState(242);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==TK_COMA) {
				{
				setState(241);
				parametros_funcion_2_a_n();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Llamada_a_funcionContext extends ParserRuleContext {
		public TerminalNode TK_PAR_IZQ() { return getToken(PsicoderParser.TK_PAR_IZQ, 0); }
		public TerminalNode TK_PAR_DER() { return getToken(PsicoderParser.TK_PAR_DER, 0); }
		public Parametros_llamada_a_funcionContext parametros_llamada_a_funcion() {
			return getRuleContext(Parametros_llamada_a_funcionContext.class,0);
		}
		public Llamada_a_funcionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_llamada_a_funcion; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterLlamada_a_funcion(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitLlamada_a_funcion(this);
		}
	}

	public final Llamada_a_funcionContext llamada_a_funcion() throws RecognitionException {
		Llamada_a_funcionContext _localctx = new Llamada_a_funcionContext(_ctx, getState());
		enterRule(_localctx, 44, RULE_llamada_a_funcion);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(244);
			match(TK_PAR_IZQ);
			setState(246);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << TK_CARACTER) | (1L << TK_ENTERO) | (1L << TK_CADENA) | (1L << TK_REAL) | (1L << VERDADERO) | (1L << FALSO) | (1L << ID))) != 0)) {
				{
				setState(245);
				parametros_llamada_a_funcion();
				}
			}

			setState(248);
			match(TK_PAR_DER);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Parametros_llamada_a_funcionContext extends ParserRuleContext {
		public Parametro_llamada_a_funcionContext parametro_llamada_a_funcion() {
			return getRuleContext(Parametro_llamada_a_funcionContext.class,0);
		}
		public Parametros_llamada_a_funcion_2_a_nContext parametros_llamada_a_funcion_2_a_n() {
			return getRuleContext(Parametros_llamada_a_funcion_2_a_nContext.class,0);
		}
		public Parametros_llamada_a_funcionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_parametros_llamada_a_funcion; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterParametros_llamada_a_funcion(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitParametros_llamada_a_funcion(this);
		}
	}

	public final Parametros_llamada_a_funcionContext parametros_llamada_a_funcion() throws RecognitionException {
		Parametros_llamada_a_funcionContext _localctx = new Parametros_llamada_a_funcionContext(_ctx, getState());
		enterRule(_localctx, 46, RULE_parametros_llamada_a_funcion);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(250);
			parametro_llamada_a_funcion();
			setState(252);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==TK_COMA) {
				{
				setState(251);
				parametros_llamada_a_funcion_2_a_n();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Parametros_llamada_a_funcion_2_a_nContext extends ParserRuleContext {
		public TerminalNode TK_COMA() { return getToken(PsicoderParser.TK_COMA, 0); }
		public Parametro_llamada_a_funcionContext parametro_llamada_a_funcion() {
			return getRuleContext(Parametro_llamada_a_funcionContext.class,0);
		}
		public Parametros_llamada_a_funcion_2_a_nContext parametros_llamada_a_funcion_2_a_n() {
			return getRuleContext(Parametros_llamada_a_funcion_2_a_nContext.class,0);
		}
		public Parametros_llamada_a_funcion_2_a_nContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_parametros_llamada_a_funcion_2_a_n; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterParametros_llamada_a_funcion_2_a_n(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitParametros_llamada_a_funcion_2_a_n(this);
		}
	}

	public final Parametros_llamada_a_funcion_2_a_nContext parametros_llamada_a_funcion_2_a_n() throws RecognitionException {
		Parametros_llamada_a_funcion_2_a_nContext _localctx = new Parametros_llamada_a_funcion_2_a_nContext(_ctx, getState());
		enterRule(_localctx, 48, RULE_parametros_llamada_a_funcion_2_a_n);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(254);
			match(TK_COMA);
			setState(255);
			parametro_llamada_a_funcion();
			setState(257);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==TK_COMA) {
				{
				setState(256);
				parametros_llamada_a_funcion_2_a_n();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Parametro_llamada_a_funcionContext extends ParserRuleContext {
		public DatoContext dato() {
			return getRuleContext(DatoContext.class,0);
		}
		public TerminalNode ID() { return getToken(PsicoderParser.ID, 0); }
		public Parametro_llamada_a_funcionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_parametro_llamada_a_funcion; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterParametro_llamada_a_funcion(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitParametro_llamada_a_funcion(this);
		}
	}

	public final Parametro_llamada_a_funcionContext parametro_llamada_a_funcion() throws RecognitionException {
		Parametro_llamada_a_funcionContext _localctx = new Parametro_llamada_a_funcionContext(_ctx, getState());
		enterRule(_localctx, 50, RULE_parametro_llamada_a_funcion);
		try {
			setState(261);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case TK_CARACTER:
			case TK_ENTERO:
			case TK_CADENA:
			case TK_REAL:
			case VERDADERO:
			case FALSO:
				enterOuterAlt(_localctx, 1);
				{
				setState(259);
				dato();
				}
				break;
			case ID:
				enterOuterAlt(_localctx, 2);
				{
				setState(260);
				match(ID);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Acciones_cuerpo_funcionContext extends ParserRuleContext {
		public AccionContext accion() {
			return getRuleContext(AccionContext.class,0);
		}
		public Acciones_cuerpo_funcionContext acciones_cuerpo_funcion() {
			return getRuleContext(Acciones_cuerpo_funcionContext.class,0);
		}
		public Acciones_cuerpo_funcionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_acciones_cuerpo_funcion; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterAcciones_cuerpo_funcion(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitAcciones_cuerpo_funcion(this);
		}
	}

	public final Acciones_cuerpo_funcionContext acciones_cuerpo_funcion() throws RecognitionException {
		Acciones_cuerpo_funcionContext _localctx = new Acciones_cuerpo_funcionContext(_ctx, getState());
		enterRule(_localctx, 52, RULE_acciones_cuerpo_funcion);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(263);
			accion();
			setState(265);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__0) | (1L << IMPRIMIR) | (1L << BOOLEANO) | (1L << CARACTER) | (1L << ENTERO) | (1L << REAL) | (1L << CADENA) | (1L << SI) | (1L << ROMPER) | (1L << PARA) | (1L << MIENTRAS) | (1L << HACER) | (1L << SELECCIONAR) | (1L << ID))) != 0)) {
				{
				setState(264);
				acciones_cuerpo_funcion();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Tipo_salida_funcionContext extends ParserRuleContext {
		public TipoContext tipo() {
			return getRuleContext(TipoContext.class,0);
		}
		public TerminalNode ID() { return getToken(PsicoderParser.ID, 0); }
		public Tipo_salida_funcionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_tipo_salida_funcion; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterTipo_salida_funcion(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitTipo_salida_funcion(this);
		}
	}

	public final Tipo_salida_funcionContext tipo_salida_funcion() throws RecognitionException {
		Tipo_salida_funcionContext _localctx = new Tipo_salida_funcionContext(_ctx, getState());
		enterRule(_localctx, 54, RULE_tipo_salida_funcion);
		try {
			setState(269);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case BOOLEANO:
			case CARACTER:
			case ENTERO:
			case REAL:
			case CADENA:
				enterOuterAlt(_localctx, 1);
				{
				setState(267);
				tipo();
				}
				break;
			case ID:
				enterOuterAlt(_localctx, 2);
				{
				setState(268);
				match(ID);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class TipoContext extends ParserRuleContext {
		public TerminalNode BOOLEANO() { return getToken(PsicoderParser.BOOLEANO, 0); }
		public TerminalNode CARACTER() { return getToken(PsicoderParser.CARACTER, 0); }
		public TerminalNode ENTERO() { return getToken(PsicoderParser.ENTERO, 0); }
		public TerminalNode REAL() { return getToken(PsicoderParser.REAL, 0); }
		public TerminalNode CADENA() { return getToken(PsicoderParser.CADENA, 0); }
		public TipoContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_tipo; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterTipo(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitTipo(this);
		}
	}

	public final TipoContext tipo() throws RecognitionException {
		TipoContext _localctx = new TipoContext(_ctx, getState());
		enterRule(_localctx, 56, RULE_tipo);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(271);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << BOOLEANO) | (1L << CARACTER) | (1L << ENTERO) | (1L << REAL) | (1L << CADENA))) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class EstructuraContext extends ParserRuleContext {
		public TerminalNode ESTRUCTURA() { return getToken(PsicoderParser.ESTRUCTURA, 0); }
		public TerminalNode ID() { return getToken(PsicoderParser.ID, 0); }
		public TerminalNode FIN_ESTRUCTURA() { return getToken(PsicoderParser.FIN_ESTRUCTURA, 0); }
		public Declaraciones_1_a_nContext declaraciones_1_a_n() {
			return getRuleContext(Declaraciones_1_a_nContext.class,0);
		}
		public EstructuraContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_estructura; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterEstructura(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitEstructura(this);
		}
	}

	public final EstructuraContext estructura() throws RecognitionException {
		EstructuraContext _localctx = new EstructuraContext(_ctx, getState());
		enterRule(_localctx, 58, RULE_estructura);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(273);
			match(ESTRUCTURA);
			setState(274);
			match(ID);
			setState(276);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << BOOLEANO) | (1L << CARACTER) | (1L << ENTERO) | (1L << REAL) | (1L << CADENA) | (1L << ID))) != 0)) {
				{
				setState(275);
				declaraciones_1_a_n();
				}
			}

			setState(278);
			match(FIN_ESTRUCTURA);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Declaraciones_1_a_nContext extends ParserRuleContext {
		public TipoContext tipo() {
			return getRuleContext(TipoContext.class,0);
		}
		public DeclaracionContext declaracion() {
			return getRuleContext(DeclaracionContext.class,0);
		}
		public Declaraciones_1_a_nContext declaraciones_1_a_n() {
			return getRuleContext(Declaraciones_1_a_nContext.class,0);
		}
		public Declaracion_instancia_objetoContext declaracion_instancia_objeto() {
			return getRuleContext(Declaracion_instancia_objetoContext.class,0);
		}
		public Declaraciones_1_a_nContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_declaraciones_1_a_n; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterDeclaraciones_1_a_n(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitDeclaraciones_1_a_n(this);
		}
	}

	public final Declaraciones_1_a_nContext declaraciones_1_a_n() throws RecognitionException {
		Declaraciones_1_a_nContext _localctx = new Declaraciones_1_a_nContext(_ctx, getState());
		enterRule(_localctx, 60, RULE_declaraciones_1_a_n);
		int _la;
		try {
			setState(289);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case BOOLEANO:
			case CARACTER:
			case ENTERO:
			case REAL:
			case CADENA:
				enterOuterAlt(_localctx, 1);
				{
				setState(280);
				tipo();
				setState(281);
				declaracion();
				setState(283);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << BOOLEANO) | (1L << CARACTER) | (1L << ENTERO) | (1L << REAL) | (1L << CADENA) | (1L << ID))) != 0)) {
					{
					setState(282);
					declaraciones_1_a_n();
					}
				}

				}
				break;
			case ID:
				enterOuterAlt(_localctx, 2);
				{
				setState(285);
				declaracion_instancia_objeto();
				setState(287);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << BOOLEANO) | (1L << CARACTER) | (1L << ENTERO) | (1L << REAL) | (1L << CADENA) | (1L << ID))) != 0)) {
					{
					setState(286);
					declaraciones_1_a_n();
					}
				}

				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Declaracion_instancia_objetoContext extends ParserRuleContext {
		public List<TerminalNode> ID() { return getTokens(PsicoderParser.ID); }
		public TerminalNode ID(int i) {
			return getToken(PsicoderParser.ID, i);
		}
		public TerminalNode TK_PYC() { return getToken(PsicoderParser.TK_PYC, 0); }
		public Declaracion_instancia_objetoContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_declaracion_instancia_objeto; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterDeclaracion_instancia_objeto(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitDeclaracion_instancia_objeto(this);
		}
	}

	public final Declaracion_instancia_objetoContext declaracion_instancia_objeto() throws RecognitionException {
		Declaracion_instancia_objetoContext _localctx = new Declaracion_instancia_objetoContext(_ctx, getState());
		enterRule(_localctx, 62, RULE_declaracion_instancia_objeto);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(291);
			match(ID);
			setState(292);
			match(ID);
			setState(293);
			match(TK_PYC);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class DeclaracionContext extends ParserRuleContext {
		public TerminalNode ID() { return getToken(PsicoderParser.ID, 0); }
		public TerminalNode TK_PYC() { return getToken(PsicoderParser.TK_PYC, 0); }
		public Inicializacion_variableContext inicializacion_variable() {
			return getRuleContext(Inicializacion_variableContext.class,0);
		}
		public Variables_2_a_nContext variables_2_a_n() {
			return getRuleContext(Variables_2_a_nContext.class,0);
		}
		public DeclaracionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_declaracion; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterDeclaracion(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitDeclaracion(this);
		}
	}

	public final DeclaracionContext declaracion() throws RecognitionException {
		DeclaracionContext _localctx = new DeclaracionContext(_ctx, getState());
		enterRule(_localctx, 64, RULE_declaracion);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(295);
			match(ID);
			setState(297);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==TK_ASIG) {
				{
				setState(296);
				inicializacion_variable();
				}
			}

			setState(300);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==TK_COMA) {
				{
				setState(299);
				variables_2_a_n();
				}
			}

			setState(302);
			match(TK_PYC);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Variables_2_a_nContext extends ParserRuleContext {
		public TerminalNode TK_COMA() { return getToken(PsicoderParser.TK_COMA, 0); }
		public TerminalNode ID() { return getToken(PsicoderParser.ID, 0); }
		public Inicializacion_variableContext inicializacion_variable() {
			return getRuleContext(Inicializacion_variableContext.class,0);
		}
		public Variables_2_a_nContext variables_2_a_n() {
			return getRuleContext(Variables_2_a_nContext.class,0);
		}
		public Variables_2_a_nContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_variables_2_a_n; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterVariables_2_a_n(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitVariables_2_a_n(this);
		}
	}

	public final Variables_2_a_nContext variables_2_a_n() throws RecognitionException {
		Variables_2_a_nContext _localctx = new Variables_2_a_nContext(_ctx, getState());
		enterRule(_localctx, 66, RULE_variables_2_a_n);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(304);
			match(TK_COMA);
			setState(305);
			match(ID);
			setState(307);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==TK_ASIG) {
				{
				setState(306);
				inicializacion_variable();
				}
			}

			setState(310);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==TK_COMA) {
				{
				setState(309);
				variables_2_a_n();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Inicializacion_variableContext extends ParserRuleContext {
		public TerminalNode TK_ASIG() { return getToken(PsicoderParser.TK_ASIG, 0); }
		public ExpresionContext expresion() {
			return getRuleContext(ExpresionContext.class,0);
		}
		public Inicializacion_variableContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_inicializacion_variable; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterInicializacion_variable(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitInicializacion_variable(this);
		}
	}

	public final Inicializacion_variableContext inicializacion_variable() throws RecognitionException {
		Inicializacion_variableContext _localctx = new Inicializacion_variableContext(_ctx, getState());
		enterRule(_localctx, 68, RULE_inicializacion_variable);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(312);
			match(TK_ASIG);
			setState(313);
			expresion();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AsignacionContext extends ParserRuleContext {
		public TerminalNode TK_ASIG() { return getToken(PsicoderParser.TK_ASIG, 0); }
		public ExpresionContext expresion() {
			return getRuleContext(ExpresionContext.class,0);
		}
		public AsignacionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_asignacion; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterAsignacion(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitAsignacion(this);
		}
	}

	public final AsignacionContext asignacion() throws RecognitionException {
		AsignacionContext _localctx = new AsignacionContext(_ctx, getState());
		enterRule(_localctx, 70, RULE_asignacion);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(315);
			match(TK_ASIG);
			setState(316);
			expresion();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Gestor_idContext extends ParserRuleContext {
		public TerminalNode ID() { return getToken(PsicoderParser.ID, 0); }
		public Variable_o_objeto_o_funcionContext variable_o_objeto_o_funcion() {
			return getRuleContext(Variable_o_objeto_o_funcionContext.class,0);
		}
		public Gestor_idContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_gestor_id; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterGestor_id(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitGestor_id(this);
		}
	}

	public final Gestor_idContext gestor_id() throws RecognitionException {
		Gestor_idContext _localctx = new Gestor_idContext(_ctx, getState());
		enterRule(_localctx, 72, RULE_gestor_id);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(318);
			match(ID);
			setState(319);
			variable_o_objeto_o_funcion();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Variable_o_objeto_o_funcionContext extends ParserRuleContext {
		public TerminalNode ID() { return getToken(PsicoderParser.ID, 0); }
		public TerminalNode TK_PYC() { return getToken(PsicoderParser.TK_PYC, 0); }
		public AsignacionContext asignacion() {
			return getRuleContext(AsignacionContext.class,0);
		}
		public Llamada_a_funcionContext llamada_a_funcion() {
			return getRuleContext(Llamada_a_funcionContext.class,0);
		}
		public TerminalNode TK_PUNTO() { return getToken(PsicoderParser.TK_PUNTO, 0); }
		public GettersContext getters() {
			return getRuleContext(GettersContext.class,0);
		}
		public Variable_o_objeto_o_funcionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_variable_o_objeto_o_funcion; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterVariable_o_objeto_o_funcion(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitVariable_o_objeto_o_funcion(this);
		}
	}

	public final Variable_o_objeto_o_funcionContext variable_o_objeto_o_funcion() throws RecognitionException {
		Variable_o_objeto_o_funcionContext _localctx = new Variable_o_objeto_o_funcionContext(_ctx, getState());
		enterRule(_localctx, 74, RULE_variable_o_objeto_o_funcion);
		int _la;
		try {
			setState(337);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case ID:
				enterOuterAlt(_localctx, 1);
				{
				setState(321);
				match(ID);
				setState(322);
				match(TK_PYC);
				}
				break;
			case TK_ASIG:
				enterOuterAlt(_localctx, 2);
				{
				setState(323);
				asignacion();
				setState(324);
				match(TK_PYC);
				}
				break;
			case TK_PAR_IZQ:
				enterOuterAlt(_localctx, 3);
				{
				setState(326);
				llamada_a_funcion();
				setState(327);
				match(TK_PYC);
				}
				break;
			case TK_PUNTO:
				enterOuterAlt(_localctx, 4);
				{
				setState(329);
				match(TK_PUNTO);
				setState(330);
				match(ID);
				setState(332);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==TK_PUNTO) {
					{
					setState(331);
					getters();
					}
				}

				setState(334);
				asignacion();
				setState(335);
				match(TK_PYC);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class CondicionalContext extends ParserRuleContext {
		public TerminalNode SI() { return getToken(PsicoderParser.SI, 0); }
		public Condicion_a_evaluarContext condicion_a_evaluar() {
			return getRuleContext(Condicion_a_evaluarContext.class,0);
		}
		public TerminalNode FIN_SI() { return getToken(PsicoderParser.FIN_SI, 0); }
		public Acciones_condicionalContext acciones_condicional() {
			return getRuleContext(Acciones_condicionalContext.class,0);
		}
		public AlternativaContext alternativa() {
			return getRuleContext(AlternativaContext.class,0);
		}
		public CondicionalContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_condicional; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterCondicional(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitCondicional(this);
		}
	}

	public final CondicionalContext condicional() throws RecognitionException {
		CondicionalContext _localctx = new CondicionalContext(_ctx, getState());
		enterRule(_localctx, 76, RULE_condicional);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(339);
			match(SI);
			setState(340);
			condicion_a_evaluar();
			setState(342);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__0) | (1L << IMPRIMIR) | (1L << BOOLEANO) | (1L << CARACTER) | (1L << ENTERO) | (1L << REAL) | (1L << CADENA) | (1L << SI) | (1L << ROMPER) | (1L << PARA) | (1L << MIENTRAS) | (1L << HACER) | (1L << SELECCIONAR) | (1L << ID))) != 0)) {
				{
				setState(341);
				acciones_condicional();
				}
			}

			setState(345);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==SI_NO) {
				{
				setState(344);
				alternativa();
				}
			}

			setState(347);
			match(FIN_SI);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Condicion_a_evaluarContext extends ParserRuleContext {
		public TerminalNode TK_PAR_IZQ() { return getToken(PsicoderParser.TK_PAR_IZQ, 0); }
		public ExpresionContext expresion() {
			return getRuleContext(ExpresionContext.class,0);
		}
		public TerminalNode TK_PAR_DER() { return getToken(PsicoderParser.TK_PAR_DER, 0); }
		public TerminalNode ENTONCES() { return getToken(PsicoderParser.ENTONCES, 0); }
		public Condicion_a_evaluarContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_condicion_a_evaluar; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterCondicion_a_evaluar(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitCondicion_a_evaluar(this);
		}
	}

	public final Condicion_a_evaluarContext condicion_a_evaluar() throws RecognitionException {
		Condicion_a_evaluarContext _localctx = new Condicion_a_evaluarContext(_ctx, getState());
		enterRule(_localctx, 78, RULE_condicion_a_evaluar);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(349);
			match(TK_PAR_IZQ);
			setState(350);
			expresion();
			setState(351);
			match(TK_PAR_DER);
			setState(352);
			match(ENTONCES);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AlternativaContext extends ParserRuleContext {
		public TerminalNode SI_NO() { return getToken(PsicoderParser.SI_NO, 0); }
		public Acciones_condicionalContext acciones_condicional() {
			return getRuleContext(Acciones_condicionalContext.class,0);
		}
		public AlternativaContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_alternativa; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterAlternativa(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitAlternativa(this);
		}
	}

	public final AlternativaContext alternativa() throws RecognitionException {
		AlternativaContext _localctx = new AlternativaContext(_ctx, getState());
		enterRule(_localctx, 80, RULE_alternativa);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(354);
			match(SI_NO);
			setState(356);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__0) | (1L << IMPRIMIR) | (1L << BOOLEANO) | (1L << CARACTER) | (1L << ENTERO) | (1L << REAL) | (1L << CADENA) | (1L << SI) | (1L << ROMPER) | (1L << PARA) | (1L << MIENTRAS) | (1L << HACER) | (1L << SELECCIONAR) | (1L << ID))) != 0)) {
				{
				setState(355);
				acciones_condicional();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Acciones_condicionalContext extends ParserRuleContext {
		public AccionContext accion() {
			return getRuleContext(AccionContext.class,0);
		}
		public Acciones_condicionalContext acciones_condicional() {
			return getRuleContext(Acciones_condicionalContext.class,0);
		}
		public Acciones_condicionalContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_acciones_condicional; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterAcciones_condicional(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitAcciones_condicional(this);
		}
	}

	public final Acciones_condicionalContext acciones_condicional() throws RecognitionException {
		Acciones_condicionalContext _localctx = new Acciones_condicionalContext(_ctx, getState());
		enterRule(_localctx, 82, RULE_acciones_condicional);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(358);
			accion();
			setState(360);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__0) | (1L << IMPRIMIR) | (1L << BOOLEANO) | (1L << CARACTER) | (1L << ENTERO) | (1L << REAL) | (1L << CADENA) | (1L << SI) | (1L << ROMPER) | (1L << PARA) | (1L << MIENTRAS) | (1L << HACER) | (1L << SELECCIONAR) | (1L << ID))) != 0)) {
				{
				setState(359);
				acciones_condicional();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AccionContext extends ParserRuleContext {
		public Gestor_idContext gestor_id() {
			return getRuleContext(Gestor_idContext.class,0);
		}
		public LecturaContext lectura() {
			return getRuleContext(LecturaContext.class,0);
		}
		public ImpresionContext impresion() {
			return getRuleContext(ImpresionContext.class,0);
		}
		public TipoContext tipo() {
			return getRuleContext(TipoContext.class,0);
		}
		public DeclaracionContext declaracion() {
			return getRuleContext(DeclaracionContext.class,0);
		}
		public CondicionalContext condicional() {
			return getRuleContext(CondicionalContext.class,0);
		}
		public Ciclo_paraContext ciclo_para() {
			return getRuleContext(Ciclo_paraContext.class,0);
		}
		public Ciclo_hacer_mientrasContext ciclo_hacer_mientras() {
			return getRuleContext(Ciclo_hacer_mientrasContext.class,0);
		}
		public Ciclo_mientrasContext ciclo_mientras() {
			return getRuleContext(Ciclo_mientrasContext.class,0);
		}
		public Comando_seleccionContext comando_seleccion() {
			return getRuleContext(Comando_seleccionContext.class,0);
		}
		public TerminalNode ROMPER() { return getToken(PsicoderParser.ROMPER, 0); }
		public TerminalNode TK_PYC() { return getToken(PsicoderParser.TK_PYC, 0); }
		public AccionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_accion; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterAccion(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitAccion(this);
		}
	}

	public final AccionContext accion() throws RecognitionException {
		AccionContext _localctx = new AccionContext(_ctx, getState());
		enterRule(_localctx, 84, RULE_accion);
		try {
			setState(375);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case ID:
				enterOuterAlt(_localctx, 1);
				{
				setState(362);
				gestor_id();
				}
				break;
			case T__0:
				enterOuterAlt(_localctx, 2);
				{
				setState(363);
				lectura();
				}
				break;
			case IMPRIMIR:
				enterOuterAlt(_localctx, 3);
				{
				setState(364);
				impresion();
				}
				break;
			case BOOLEANO:
			case CARACTER:
			case ENTERO:
			case REAL:
			case CADENA:
				enterOuterAlt(_localctx, 4);
				{
				setState(365);
				tipo();
				setState(366);
				declaracion();
				}
				break;
			case SI:
				enterOuterAlt(_localctx, 5);
				{
				setState(368);
				condicional();
				}
				break;
			case PARA:
				enterOuterAlt(_localctx, 6);
				{
				setState(369);
				ciclo_para();
				}
				break;
			case HACER:
				enterOuterAlt(_localctx, 7);
				{
				setState(370);
				ciclo_hacer_mientras();
				}
				break;
			case MIENTRAS:
				enterOuterAlt(_localctx, 8);
				{
				setState(371);
				ciclo_mientras();
				}
				break;
			case SELECCIONAR:
				enterOuterAlt(_localctx, 9);
				{
				setState(372);
				comando_seleccion();
				}
				break;
			case ROMPER:
				enterOuterAlt(_localctx, 10);
				{
				setState(373);
				match(ROMPER);
				setState(374);
				match(TK_PYC);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Ciclo_paraContext extends ParserRuleContext {
		public TerminalNode PARA() { return getToken(PsicoderParser.PARA, 0); }
		public TerminalNode TK_PAR_IZQ() { return getToken(PsicoderParser.TK_PAR_IZQ, 0); }
		public Inicializacion_ciclo_paraContext inicializacion_ciclo_para() {
			return getRuleContext(Inicializacion_ciclo_paraContext.class,0);
		}
		public PasoContext paso() {
			return getRuleContext(PasoContext.class,0);
		}
		public TerminalNode FIN_PARA() { return getToken(PsicoderParser.FIN_PARA, 0); }
		public Acciones_ciclo_paraContext acciones_ciclo_para() {
			return getRuleContext(Acciones_ciclo_paraContext.class,0);
		}
		public Ciclo_paraContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_ciclo_para; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterCiclo_para(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitCiclo_para(this);
		}
	}

	public final Ciclo_paraContext ciclo_para() throws RecognitionException {
		Ciclo_paraContext _localctx = new Ciclo_paraContext(_ctx, getState());
		enterRule(_localctx, 86, RULE_ciclo_para);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(377);
			match(PARA);
			setState(378);
			match(TK_PAR_IZQ);
			setState(379);
			inicializacion_ciclo_para();
			setState(380);
			paso();
			setState(382);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__0) | (1L << IMPRIMIR) | (1L << BOOLEANO) | (1L << CARACTER) | (1L << ENTERO) | (1L << REAL) | (1L << CADENA) | (1L << SI) | (1L << ROMPER) | (1L << PARA) | (1L << MIENTRAS) | (1L << HACER) | (1L << SELECCIONAR) | (1L << ID))) != 0)) {
				{
				setState(381);
				acciones_ciclo_para();
				}
			}

			setState(384);
			match(FIN_PARA);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Inicializacion_ciclo_paraContext extends ParserRuleContext {
		public TerminalNode ENTERO() { return getToken(PsicoderParser.ENTERO, 0); }
		public TerminalNode ID() { return getToken(PsicoderParser.ID, 0); }
		public TerminalNode TK_ASIG() { return getToken(PsicoderParser.TK_ASIG, 0); }
		public TerminalNode TK_ENTERO() { return getToken(PsicoderParser.TK_ENTERO, 0); }
		public TerminalNode TK_PYC() { return getToken(PsicoderParser.TK_PYC, 0); }
		public ExpresionContext expresion() {
			return getRuleContext(ExpresionContext.class,0);
		}
		public Inicializacion_ciclo_paraContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_inicializacion_ciclo_para; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterInicializacion_ciclo_para(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitInicializacion_ciclo_para(this);
		}
	}

	public final Inicializacion_ciclo_paraContext inicializacion_ciclo_para() throws RecognitionException {
		Inicializacion_ciclo_paraContext _localctx = new Inicializacion_ciclo_paraContext(_ctx, getState());
		enterRule(_localctx, 88, RULE_inicializacion_ciclo_para);
		try {
			setState(397);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case ENTERO:
				enterOuterAlt(_localctx, 1);
				{
				setState(386);
				match(ENTERO);
				setState(387);
				match(ID);
				setState(388);
				match(TK_ASIG);
				setState(389);
				match(TK_ENTERO);
				setState(390);
				match(TK_PYC);
				setState(391);
				expresion();
				}
				break;
			case ID:
				enterOuterAlt(_localctx, 2);
				{
				setState(392);
				match(ID);
				setState(393);
				match(TK_ASIG);
				setState(394);
				match(TK_ENTERO);
				setState(395);
				match(TK_PYC);
				setState(396);
				expresion();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class PasoContext extends ParserRuleContext {
		public TerminalNode TK_PYC() { return getToken(PsicoderParser.TK_PYC, 0); }
		public TerminalNode ID() { return getToken(PsicoderParser.ID, 0); }
		public TerminalNode TK_PAR_DER() { return getToken(PsicoderParser.TK_PAR_DER, 0); }
		public TerminalNode HACER() { return getToken(PsicoderParser.HACER, 0); }
		public TerminalNode TK_ENTERO() { return getToken(PsicoderParser.TK_ENTERO, 0); }
		public PasoContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_paso; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterPaso(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitPaso(this);
		}
	}

	public final PasoContext paso() throws RecognitionException {
		PasoContext _localctx = new PasoContext(_ctx, getState());
		enterRule(_localctx, 90, RULE_paso);
		try {
			setState(407);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,39,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(399);
				match(TK_PYC);
				setState(400);
				match(ID);
				setState(401);
				match(TK_PAR_DER);
				setState(402);
				match(HACER);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(403);
				match(TK_PYC);
				setState(404);
				match(TK_ENTERO);
				setState(405);
				match(TK_PAR_DER);
				setState(406);
				match(HACER);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Acciones_ciclo_paraContext extends ParserRuleContext {
		public AccionContext accion() {
			return getRuleContext(AccionContext.class,0);
		}
		public Acciones_ciclo_paraContext acciones_ciclo_para() {
			return getRuleContext(Acciones_ciclo_paraContext.class,0);
		}
		public Acciones_ciclo_paraContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_acciones_ciclo_para; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterAcciones_ciclo_para(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitAcciones_ciclo_para(this);
		}
	}

	public final Acciones_ciclo_paraContext acciones_ciclo_para() throws RecognitionException {
		Acciones_ciclo_paraContext _localctx = new Acciones_ciclo_paraContext(_ctx, getState());
		enterRule(_localctx, 92, RULE_acciones_ciclo_para);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(409);
			accion();
			setState(411);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__0) | (1L << IMPRIMIR) | (1L << BOOLEANO) | (1L << CARACTER) | (1L << ENTERO) | (1L << REAL) | (1L << CADENA) | (1L << SI) | (1L << ROMPER) | (1L << PARA) | (1L << MIENTRAS) | (1L << HACER) | (1L << SELECCIONAR) | (1L << ID))) != 0)) {
				{
				setState(410);
				acciones_ciclo_para();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Ciclo_mientrasContext extends ParserRuleContext {
		public TerminalNode MIENTRAS() { return getToken(PsicoderParser.MIENTRAS, 0); }
		public Condicion_mientrasContext condicion_mientras() {
			return getRuleContext(Condicion_mientrasContext.class,0);
		}
		public TerminalNode FIN_MIENTRAS() { return getToken(PsicoderParser.FIN_MIENTRAS, 0); }
		public Acciones_mientrasContext acciones_mientras() {
			return getRuleContext(Acciones_mientrasContext.class,0);
		}
		public Ciclo_mientrasContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_ciclo_mientras; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterCiclo_mientras(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitCiclo_mientras(this);
		}
	}

	public final Ciclo_mientrasContext ciclo_mientras() throws RecognitionException {
		Ciclo_mientrasContext _localctx = new Ciclo_mientrasContext(_ctx, getState());
		enterRule(_localctx, 94, RULE_ciclo_mientras);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(413);
			match(MIENTRAS);
			setState(414);
			condicion_mientras();
			setState(416);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__0) | (1L << IMPRIMIR) | (1L << BOOLEANO) | (1L << CARACTER) | (1L << ENTERO) | (1L << REAL) | (1L << CADENA) | (1L << SI) | (1L << ROMPER) | (1L << PARA) | (1L << MIENTRAS) | (1L << HACER) | (1L << SELECCIONAR) | (1L << ID))) != 0)) {
				{
				setState(415);
				acciones_mientras();
				}
			}

			setState(418);
			match(FIN_MIENTRAS);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Condicion_mientrasContext extends ParserRuleContext {
		public TerminalNode TK_PAR_IZQ() { return getToken(PsicoderParser.TK_PAR_IZQ, 0); }
		public ExpresionContext expresion() {
			return getRuleContext(ExpresionContext.class,0);
		}
		public TerminalNode TK_PAR_DER() { return getToken(PsicoderParser.TK_PAR_DER, 0); }
		public TerminalNode HACER() { return getToken(PsicoderParser.HACER, 0); }
		public Condicion_mientrasContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_condicion_mientras; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterCondicion_mientras(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitCondicion_mientras(this);
		}
	}

	public final Condicion_mientrasContext condicion_mientras() throws RecognitionException {
		Condicion_mientrasContext _localctx = new Condicion_mientrasContext(_ctx, getState());
		enterRule(_localctx, 96, RULE_condicion_mientras);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(420);
			match(TK_PAR_IZQ);
			setState(421);
			expresion();
			setState(422);
			match(TK_PAR_DER);
			setState(423);
			match(HACER);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Acciones_mientrasContext extends ParserRuleContext {
		public AccionContext accion() {
			return getRuleContext(AccionContext.class,0);
		}
		public Acciones_mientrasContext acciones_mientras() {
			return getRuleContext(Acciones_mientrasContext.class,0);
		}
		public Acciones_mientrasContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_acciones_mientras; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterAcciones_mientras(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitAcciones_mientras(this);
		}
	}

	public final Acciones_mientrasContext acciones_mientras() throws RecognitionException {
		Acciones_mientrasContext _localctx = new Acciones_mientrasContext(_ctx, getState());
		enterRule(_localctx, 98, RULE_acciones_mientras);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(425);
			accion();
			setState(427);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__0) | (1L << IMPRIMIR) | (1L << BOOLEANO) | (1L << CARACTER) | (1L << ENTERO) | (1L << REAL) | (1L << CADENA) | (1L << SI) | (1L << ROMPER) | (1L << PARA) | (1L << MIENTRAS) | (1L << HACER) | (1L << SELECCIONAR) | (1L << ID))) != 0)) {
				{
				setState(426);
				acciones_mientras();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Ciclo_hacer_mientrasContext extends ParserRuleContext {
		public TerminalNode HACER() { return getToken(PsicoderParser.HACER, 0); }
		public Clausula_mientrasContext clausula_mientras() {
			return getRuleContext(Clausula_mientrasContext.class,0);
		}
		public Acciones_hacer_mientrasContext acciones_hacer_mientras() {
			return getRuleContext(Acciones_hacer_mientrasContext.class,0);
		}
		public Ciclo_hacer_mientrasContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_ciclo_hacer_mientras; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterCiclo_hacer_mientras(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitCiclo_hacer_mientras(this);
		}
	}

	public final Ciclo_hacer_mientrasContext ciclo_hacer_mientras() throws RecognitionException {
		Ciclo_hacer_mientrasContext _localctx = new Ciclo_hacer_mientrasContext(_ctx, getState());
		enterRule(_localctx, 100, RULE_ciclo_hacer_mientras);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(429);
			match(HACER);
			setState(431);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,43,_ctx) ) {
			case 1:
				{
				setState(430);
				acciones_hacer_mientras();
				}
				break;
			}
			setState(433);
			clausula_mientras();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Acciones_hacer_mientrasContext extends ParserRuleContext {
		public Accion_chmContext accion_chm() {
			return getRuleContext(Accion_chmContext.class,0);
		}
		public Acciones_hacer_mientrasContext acciones_hacer_mientras() {
			return getRuleContext(Acciones_hacer_mientrasContext.class,0);
		}
		public Acciones_hacer_mientrasContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_acciones_hacer_mientras; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterAcciones_hacer_mientras(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitAcciones_hacer_mientras(this);
		}
	}

	public final Acciones_hacer_mientrasContext acciones_hacer_mientras() throws RecognitionException {
		Acciones_hacer_mientrasContext _localctx = new Acciones_hacer_mientrasContext(_ctx, getState());
		enterRule(_localctx, 102, RULE_acciones_hacer_mientras);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(435);
			accion_chm();
			setState(437);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,44,_ctx) ) {
			case 1:
				{
				setState(436);
				acciones_hacer_mientras();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Clausula_mientrasContext extends ParserRuleContext {
		public TerminalNode MIENTRAS() { return getToken(PsicoderParser.MIENTRAS, 0); }
		public Condicion_clausula_mientrasContext condicion_clausula_mientras() {
			return getRuleContext(Condicion_clausula_mientrasContext.class,0);
		}
		public TerminalNode TK_PYC() { return getToken(PsicoderParser.TK_PYC, 0); }
		public Clausula_mientrasContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_clausula_mientras; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterClausula_mientras(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitClausula_mientras(this);
		}
	}

	public final Clausula_mientrasContext clausula_mientras() throws RecognitionException {
		Clausula_mientrasContext _localctx = new Clausula_mientrasContext(_ctx, getState());
		enterRule(_localctx, 104, RULE_clausula_mientras);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(439);
			match(MIENTRAS);
			setState(440);
			condicion_clausula_mientras();
			setState(441);
			match(TK_PYC);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Condicion_clausula_mientrasContext extends ParserRuleContext {
		public TerminalNode TK_PAR_IZQ() { return getToken(PsicoderParser.TK_PAR_IZQ, 0); }
		public ExpresionContext expresion() {
			return getRuleContext(ExpresionContext.class,0);
		}
		public TerminalNode TK_PAR_DER() { return getToken(PsicoderParser.TK_PAR_DER, 0); }
		public Condicion_clausula_mientrasContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_condicion_clausula_mientras; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterCondicion_clausula_mientras(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitCondicion_clausula_mientras(this);
		}
	}

	public final Condicion_clausula_mientrasContext condicion_clausula_mientras() throws RecognitionException {
		Condicion_clausula_mientrasContext _localctx = new Condicion_clausula_mientrasContext(_ctx, getState());
		enterRule(_localctx, 106, RULE_condicion_clausula_mientras);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(443);
			match(TK_PAR_IZQ);
			setState(444);
			expresion();
			setState(445);
			match(TK_PAR_DER);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Accion_chmContext extends ParserRuleContext {
		public Gestor_idContext gestor_id() {
			return getRuleContext(Gestor_idContext.class,0);
		}
		public ImpresionContext impresion() {
			return getRuleContext(ImpresionContext.class,0);
		}
		public LecturaContext lectura() {
			return getRuleContext(LecturaContext.class,0);
		}
		public TipoContext tipo() {
			return getRuleContext(TipoContext.class,0);
		}
		public DeclaracionContext declaracion() {
			return getRuleContext(DeclaracionContext.class,0);
		}
		public CondicionalContext condicional() {
			return getRuleContext(CondicionalContext.class,0);
		}
		public Ciclo_paraContext ciclo_para() {
			return getRuleContext(Ciclo_paraContext.class,0);
		}
		public Ciclo_hacer_mientrasContext ciclo_hacer_mientras() {
			return getRuleContext(Ciclo_hacer_mientrasContext.class,0);
		}
		public Ciclo_mientrasContext ciclo_mientras() {
			return getRuleContext(Ciclo_mientrasContext.class,0);
		}
		public Comando_seleccionContext comando_seleccion() {
			return getRuleContext(Comando_seleccionContext.class,0);
		}
		public TerminalNode ROMPER() { return getToken(PsicoderParser.ROMPER, 0); }
		public TerminalNode TK_PYC() { return getToken(PsicoderParser.TK_PYC, 0); }
		public Accion_chmContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_accion_chm; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterAccion_chm(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitAccion_chm(this);
		}
	}

	public final Accion_chmContext accion_chm() throws RecognitionException {
		Accion_chmContext _localctx = new Accion_chmContext(_ctx, getState());
		enterRule(_localctx, 108, RULE_accion_chm);
		try {
			setState(460);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case ID:
				enterOuterAlt(_localctx, 1);
				{
				setState(447);
				gestor_id();
				}
				break;
			case IMPRIMIR:
				enterOuterAlt(_localctx, 2);
				{
				setState(448);
				impresion();
				}
				break;
			case T__0:
				enterOuterAlt(_localctx, 3);
				{
				setState(449);
				lectura();
				}
				break;
			case BOOLEANO:
			case CARACTER:
			case ENTERO:
			case REAL:
			case CADENA:
				enterOuterAlt(_localctx, 4);
				{
				setState(450);
				tipo();
				setState(451);
				declaracion();
				}
				break;
			case SI:
				enterOuterAlt(_localctx, 5);
				{
				setState(453);
				condicional();
				}
				break;
			case PARA:
				enterOuterAlt(_localctx, 6);
				{
				setState(454);
				ciclo_para();
				}
				break;
			case HACER:
				enterOuterAlt(_localctx, 7);
				{
				setState(455);
				ciclo_hacer_mientras();
				}
				break;
			case MIENTRAS:
				enterOuterAlt(_localctx, 8);
				{
				setState(456);
				ciclo_mientras();
				}
				break;
			case SELECCIONAR:
				enterOuterAlt(_localctx, 9);
				{
				setState(457);
				comando_seleccion();
				}
				break;
			case ROMPER:
				enterOuterAlt(_localctx, 10);
				{
				setState(458);
				match(ROMPER);
				setState(459);
				match(TK_PYC);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Comando_seleccionContext extends ParserRuleContext {
		public TerminalNode SELECCIONAR() { return getToken(PsicoderParser.SELECCIONAR, 0); }
		public TerminalNode TK_PAR_IZQ() { return getToken(PsicoderParser.TK_PAR_IZQ, 0); }
		public TerminalNode ID() { return getToken(PsicoderParser.ID, 0); }
		public TerminalNode TK_PAR_DER() { return getToken(PsicoderParser.TK_PAR_DER, 0); }
		public TerminalNode ENTRE() { return getToken(PsicoderParser.ENTRE, 0); }
		public CasosContext casos() {
			return getRuleContext(CasosContext.class,0);
		}
		public TerminalNode FIN_SELECCIONAR() { return getToken(PsicoderParser.FIN_SELECCIONAR, 0); }
		public Comando_seleccionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_comando_seleccion; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterComando_seleccion(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitComando_seleccion(this);
		}
	}

	public final Comando_seleccionContext comando_seleccion() throws RecognitionException {
		Comando_seleccionContext _localctx = new Comando_seleccionContext(_ctx, getState());
		enterRule(_localctx, 110, RULE_comando_seleccion);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(462);
			match(SELECCIONAR);
			setState(463);
			match(TK_PAR_IZQ);
			setState(464);
			match(ID);
			setState(465);
			match(TK_PAR_DER);
			setState(466);
			match(ENTRE);
			setState(467);
			casos();
			setState(468);
			match(FIN_SELECCIONAR);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class CasosContext extends ParserRuleContext {
		public Caso_defectoContext caso_defecto() {
			return getRuleContext(Caso_defectoContext.class,0);
		}
		public Uno_o_mas_casosContext uno_o_mas_casos() {
			return getRuleContext(Uno_o_mas_casosContext.class,0);
		}
		public CasosContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_casos; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterCasos(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitCasos(this);
		}
	}

	public final CasosContext casos() throws RecognitionException {
		CasosContext _localctx = new CasosContext(_ctx, getState());
		enterRule(_localctx, 112, RULE_casos);
		try {
			setState(472);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case DEFECTO:
				enterOuterAlt(_localctx, 1);
				{
				setState(470);
				caso_defecto();
				}
				break;
			case CASO:
				enterOuterAlt(_localctx, 2);
				{
				setState(471);
				uno_o_mas_casos();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Caso_defectoContext extends ParserRuleContext {
		public TerminalNode DEFECTO() { return getToken(PsicoderParser.DEFECTO, 0); }
		public TerminalNode TK_DOSP() { return getToken(PsicoderParser.TK_DOSP, 0); }
		public Acciones_comando_seleccionContext acciones_comando_seleccion() {
			return getRuleContext(Acciones_comando_seleccionContext.class,0);
		}
		public RompimientoContext rompimiento() {
			return getRuleContext(RompimientoContext.class,0);
		}
		public Caso_defectoContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_caso_defecto; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterCaso_defecto(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitCaso_defecto(this);
		}
	}

	public final Caso_defectoContext caso_defecto() throws RecognitionException {
		Caso_defectoContext _localctx = new Caso_defectoContext(_ctx, getState());
		enterRule(_localctx, 114, RULE_caso_defecto);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(474);
			match(DEFECTO);
			setState(475);
			match(TK_DOSP);
			setState(477);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__0) | (1L << IMPRIMIR) | (1L << BOOLEANO) | (1L << CARACTER) | (1L << ENTERO) | (1L << REAL) | (1L << CADENA) | (1L << SI) | (1L << PARA) | (1L << MIENTRAS) | (1L << HACER) | (1L << SELECCIONAR) | (1L << ID))) != 0)) {
				{
				setState(476);
				acciones_comando_seleccion();
				}
			}

			setState(480);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==ROMPER) {
				{
				setState(479);
				rompimiento();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Uno_o_mas_casosContext extends ParserRuleContext {
		public TerminalNode CASO() { return getToken(PsicoderParser.CASO, 0); }
		public TerminalNode TK_ENTERO() { return getToken(PsicoderParser.TK_ENTERO, 0); }
		public TerminalNode TK_DOSP() { return getToken(PsicoderParser.TK_DOSP, 0); }
		public Acciones_comando_seleccionContext acciones_comando_seleccion() {
			return getRuleContext(Acciones_comando_seleccionContext.class,0);
		}
		public RompimientoContext rompimiento() {
			return getRuleContext(RompimientoContext.class,0);
		}
		public Casos_2_a_nContext casos_2_a_n() {
			return getRuleContext(Casos_2_a_nContext.class,0);
		}
		public Uno_o_mas_casosContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_uno_o_mas_casos; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterUno_o_mas_casos(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitUno_o_mas_casos(this);
		}
	}

	public final Uno_o_mas_casosContext uno_o_mas_casos() throws RecognitionException {
		Uno_o_mas_casosContext _localctx = new Uno_o_mas_casosContext(_ctx, getState());
		enterRule(_localctx, 116, RULE_uno_o_mas_casos);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(482);
			match(CASO);
			setState(483);
			match(TK_ENTERO);
			setState(484);
			match(TK_DOSP);
			setState(486);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__0) | (1L << IMPRIMIR) | (1L << BOOLEANO) | (1L << CARACTER) | (1L << ENTERO) | (1L << REAL) | (1L << CADENA) | (1L << SI) | (1L << PARA) | (1L << MIENTRAS) | (1L << HACER) | (1L << SELECCIONAR) | (1L << ID))) != 0)) {
				{
				setState(485);
				acciones_comando_seleccion();
				}
			}

			setState(489);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==ROMPER) {
				{
				setState(488);
				rompimiento();
				}
			}

			setState(492);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==DEFECTO || _la==CASO) {
				{
				setState(491);
				casos_2_a_n();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Casos_2_a_nContext extends ParserRuleContext {
		public TerminalNode CASO() { return getToken(PsicoderParser.CASO, 0); }
		public TerminalNode TK_ENTERO() { return getToken(PsicoderParser.TK_ENTERO, 0); }
		public TerminalNode TK_DOSP() { return getToken(PsicoderParser.TK_DOSP, 0); }
		public Acciones_comando_seleccionContext acciones_comando_seleccion() {
			return getRuleContext(Acciones_comando_seleccionContext.class,0);
		}
		public RompimientoContext rompimiento() {
			return getRuleContext(RompimientoContext.class,0);
		}
		public Casos_2_a_nContext casos_2_a_n() {
			return getRuleContext(Casos_2_a_nContext.class,0);
		}
		public Caso_defectoContext caso_defecto() {
			return getRuleContext(Caso_defectoContext.class,0);
		}
		public Casos_2_a_nContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_casos_2_a_n; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterCasos_2_a_n(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitCasos_2_a_n(this);
		}
	}

	public final Casos_2_a_nContext casos_2_a_n() throws RecognitionException {
		Casos_2_a_nContext _localctx = new Casos_2_a_nContext(_ctx, getState());
		enterRule(_localctx, 118, RULE_casos_2_a_n);
		int _la;
		try {
			setState(507);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case CASO:
				enterOuterAlt(_localctx, 1);
				{
				setState(494);
				match(CASO);
				setState(495);
				match(TK_ENTERO);
				setState(496);
				match(TK_DOSP);
				setState(498);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__0) | (1L << IMPRIMIR) | (1L << BOOLEANO) | (1L << CARACTER) | (1L << ENTERO) | (1L << REAL) | (1L << CADENA) | (1L << SI) | (1L << PARA) | (1L << MIENTRAS) | (1L << HACER) | (1L << SELECCIONAR) | (1L << ID))) != 0)) {
					{
					setState(497);
					acciones_comando_seleccion();
					}
				}

				setState(501);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==ROMPER) {
					{
					setState(500);
					rompimiento();
					}
				}

				setState(504);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==DEFECTO || _la==CASO) {
					{
					setState(503);
					casos_2_a_n();
					}
				}

				}
				break;
			case DEFECTO:
				enterOuterAlt(_localctx, 2);
				{
				setState(506);
				caso_defecto();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class RompimientoContext extends ParserRuleContext {
		public TerminalNode ROMPER() { return getToken(PsicoderParser.ROMPER, 0); }
		public TerminalNode TK_PYC() { return getToken(PsicoderParser.TK_PYC, 0); }
		public RompimientoContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_rompimiento; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterRompimiento(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitRompimiento(this);
		}
	}

	public final RompimientoContext rompimiento() throws RecognitionException {
		RompimientoContext _localctx = new RompimientoContext(_ctx, getState());
		enterRule(_localctx, 120, RULE_rompimiento);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(509);
			match(ROMPER);
			setState(510);
			match(TK_PYC);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Acciones_comando_seleccionContext extends ParserRuleContext {
		public Accion_seleccionContext accion_seleccion() {
			return getRuleContext(Accion_seleccionContext.class,0);
		}
		public Acciones_comando_seleccionContext acciones_comando_seleccion() {
			return getRuleContext(Acciones_comando_seleccionContext.class,0);
		}
		public Acciones_comando_seleccionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_acciones_comando_seleccion; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterAcciones_comando_seleccion(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitAcciones_comando_seleccion(this);
		}
	}

	public final Acciones_comando_seleccionContext acciones_comando_seleccion() throws RecognitionException {
		Acciones_comando_seleccionContext _localctx = new Acciones_comando_seleccionContext(_ctx, getState());
		enterRule(_localctx, 122, RULE_acciones_comando_seleccion);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(512);
			accion_seleccion();
			setState(514);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__0) | (1L << IMPRIMIR) | (1L << BOOLEANO) | (1L << CARACTER) | (1L << ENTERO) | (1L << REAL) | (1L << CADENA) | (1L << SI) | (1L << PARA) | (1L << MIENTRAS) | (1L << HACER) | (1L << SELECCIONAR) | (1L << ID))) != 0)) {
				{
				setState(513);
				acciones_comando_seleccion();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Accion_seleccionContext extends ParserRuleContext {
		public Gestor_idContext gestor_id() {
			return getRuleContext(Gestor_idContext.class,0);
		}
		public ImpresionContext impresion() {
			return getRuleContext(ImpresionContext.class,0);
		}
		public LecturaContext lectura() {
			return getRuleContext(LecturaContext.class,0);
		}
		public TipoContext tipo() {
			return getRuleContext(TipoContext.class,0);
		}
		public DeclaracionContext declaracion() {
			return getRuleContext(DeclaracionContext.class,0);
		}
		public CondicionalContext condicional() {
			return getRuleContext(CondicionalContext.class,0);
		}
		public Ciclo_paraContext ciclo_para() {
			return getRuleContext(Ciclo_paraContext.class,0);
		}
		public Ciclo_hacer_mientrasContext ciclo_hacer_mientras() {
			return getRuleContext(Ciclo_hacer_mientrasContext.class,0);
		}
		public Ciclo_mientrasContext ciclo_mientras() {
			return getRuleContext(Ciclo_mientrasContext.class,0);
		}
		public Comando_seleccionContext comando_seleccion() {
			return getRuleContext(Comando_seleccionContext.class,0);
		}
		public Accion_seleccionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_accion_seleccion; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterAccion_seleccion(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitAccion_seleccion(this);
		}
	}

	public final Accion_seleccionContext accion_seleccion() throws RecognitionException {
		Accion_seleccionContext _localctx = new Accion_seleccionContext(_ctx, getState());
		enterRule(_localctx, 124, RULE_accion_seleccion);
		try {
			setState(528);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,57,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(516);
				gestor_id();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(517);
				impresion();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(518);
				lectura();
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(519);
				impresion();
				}
				break;
			case 5:
				enterOuterAlt(_localctx, 5);
				{
				setState(520);
				tipo();
				setState(521);
				declaracion();
				}
				break;
			case 6:
				enterOuterAlt(_localctx, 6);
				{
				setState(523);
				condicional();
				}
				break;
			case 7:
				enterOuterAlt(_localctx, 7);
				{
				setState(524);
				ciclo_para();
				}
				break;
			case 8:
				enterOuterAlt(_localctx, 8);
				{
				setState(525);
				ciclo_hacer_mientras();
				}
				break;
			case 9:
				enterOuterAlt(_localctx, 9);
				{
				setState(526);
				ciclo_mientras();
				}
				break;
			case 10:
				enterOuterAlt(_localctx, 10);
				{
				setState(527);
				comando_seleccion();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Estructuras_y_funcionesContext extends ParserRuleContext {
		public Estructura_o_funcionContext estructura_o_funcion() {
			return getRuleContext(Estructura_o_funcionContext.class,0);
		}
		public Estructuras_y_funcionesContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_estructuras_y_funciones; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterEstructuras_y_funciones(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitEstructuras_y_funciones(this);
		}
	}

	public final Estructuras_y_funcionesContext estructuras_y_funciones() throws RecognitionException {
		Estructuras_y_funcionesContext _localctx = new Estructuras_y_funcionesContext(_ctx, getState());
		enterRule(_localctx, 126, RULE_estructuras_y_funciones);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(531);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==FUNCION || _la==ESTRUCTURA) {
				{
				setState(530);
				estructura_o_funcion();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Estructura_o_funcionContext extends ParserRuleContext {
		public EstructuraContext estructura() {
			return getRuleContext(EstructuraContext.class,0);
		}
		public Estructura_o_funcionContext estructura_o_funcion() {
			return getRuleContext(Estructura_o_funcionContext.class,0);
		}
		public FuncionContext funcion() {
			return getRuleContext(FuncionContext.class,0);
		}
		public Estructura_o_funcionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_estructura_o_funcion; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterEstructura_o_funcion(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitEstructura_o_funcion(this);
		}
	}

	public final Estructura_o_funcionContext estructura_o_funcion() throws RecognitionException {
		Estructura_o_funcionContext _localctx = new Estructura_o_funcionContext(_ctx, getState());
		enterRule(_localctx, 128, RULE_estructura_o_funcion);
		int _la;
		try {
			setState(541);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case ESTRUCTURA:
				enterOuterAlt(_localctx, 1);
				{
				setState(533);
				estructura();
				setState(535);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==FUNCION || _la==ESTRUCTURA) {
					{
					setState(534);
					estructura_o_funcion();
					}
				}

				}
				break;
			case FUNCION:
				enterOuterAlt(_localctx, 2);
				{
				setState(537);
				funcion();
				setState(539);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==FUNCION || _la==ESTRUCTURA) {
					{
					setState(538);
					estructura_o_funcion();
					}
				}

				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Funcion_principalContext extends ParserRuleContext {
		public TerminalNode FUNCION_PRINCIPAL() { return getToken(PsicoderParser.FUNCION_PRINCIPAL, 0); }
		public TerminalNode FIN_PRINCIPAL() { return getToken(PsicoderParser.FIN_PRINCIPAL, 0); }
		public Acciones_funcion_principalContext acciones_funcion_principal() {
			return getRuleContext(Acciones_funcion_principalContext.class,0);
		}
		public Funcion_principalContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_funcion_principal; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterFuncion_principal(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitFuncion_principal(this);
		}
	}

	public final Funcion_principalContext funcion_principal() throws RecognitionException {
		Funcion_principalContext _localctx = new Funcion_principalContext(_ctx, getState());
		enterRule(_localctx, 130, RULE_funcion_principal);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(543);
			match(FUNCION_PRINCIPAL);
			setState(545);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__0) | (1L << IMPRIMIR) | (1L << BOOLEANO) | (1L << CARACTER) | (1L << ENTERO) | (1L << REAL) | (1L << CADENA) | (1L << SI) | (1L << ROMPER) | (1L << PARA) | (1L << MIENTRAS) | (1L << HACER) | (1L << SELECCIONAR) | (1L << ID))) != 0)) {
				{
				setState(544);
				acciones_funcion_principal();
				}
			}

			setState(547);
			match(FIN_PRINCIPAL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Acciones_funcion_principalContext extends ParserRuleContext {
		public AccionContext accion() {
			return getRuleContext(AccionContext.class,0);
		}
		public Acciones_funcion_principalContext acciones_funcion_principal() {
			return getRuleContext(Acciones_funcion_principalContext.class,0);
		}
		public Acciones_funcion_principalContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_acciones_funcion_principal; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterAcciones_funcion_principal(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitAcciones_funcion_principal(this);
		}
	}

	public final Acciones_funcion_principalContext acciones_funcion_principal() throws RecognitionException {
		Acciones_funcion_principalContext _localctx = new Acciones_funcion_principalContext(_ctx, getState());
		enterRule(_localctx, 132, RULE_acciones_funcion_principal);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(549);
			accion();
			setState(551);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__0) | (1L << IMPRIMIR) | (1L << BOOLEANO) | (1L << CARACTER) | (1L << ENTERO) | (1L << REAL) | (1L << CADENA) | (1L << SI) | (1L << ROMPER) | (1L << PARA) | (1L << MIENTRAS) | (1L << HACER) | (1L << SELECCIONAR) | (1L << ID))) != 0)) {
				{
				setState(550);
				acciones_funcion_principal();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Programa_en_psicoderContext extends ParserRuleContext {
		public Funcion_principalContext funcion_principal() {
			return getRuleContext(Funcion_principalContext.class,0);
		}
		public List<Estructuras_y_funcionesContext> estructuras_y_funciones() {
			return getRuleContexts(Estructuras_y_funcionesContext.class);
		}
		public Estructuras_y_funcionesContext estructuras_y_funciones(int i) {
			return getRuleContext(Estructuras_y_funcionesContext.class,i);
		}
		public Programa_en_psicoderContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_programa_en_psicoder; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterPrograma_en_psicoder(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitPrograma_en_psicoder(this);
		}
	}

	public final Programa_en_psicoderContext programa_en_psicoder() throws RecognitionException {
		Programa_en_psicoderContext _localctx = new Programa_en_psicoderContext(_ctx, getState());
		enterRule(_localctx, 134, RULE_programa_en_psicoder);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(554);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,64,_ctx) ) {
			case 1:
				{
				setState(553);
				estructuras_y_funciones();
				}
				break;
			}
			setState(556);
			funcion_principal();
			setState(558);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,65,_ctx) ) {
			case 1:
				{
				setState(557);
				estructuras_y_funciones();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static final String _serializedATN =
		"\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3?\u0233\4\2\t\2\4"+
		"\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b\t\b\4\t\t\t\4\n\t\n\4\13\t"+
		"\13\4\f\t\f\4\r\t\r\4\16\t\16\4\17\t\17\4\20\t\20\4\21\t\21\4\22\t\22"+
		"\4\23\t\23\4\24\t\24\4\25\t\25\4\26\t\26\4\27\t\27\4\30\t\30\4\31\t\31"+
		"\4\32\t\32\4\33\t\33\4\34\t\34\4\35\t\35\4\36\t\36\4\37\t\37\4 \t \4!"+
		"\t!\4\"\t\"\4#\t#\4$\t$\4%\t%\4&\t&\4\'\t\'\4(\t(\4)\t)\4*\t*\4+\t+\4"+
		",\t,\4-\t-\4.\t.\4/\t/\4\60\t\60\4\61\t\61\4\62\t\62\4\63\t\63\4\64\t"+
		"\64\4\65\t\65\4\66\t\66\4\67\t\67\48\t8\49\t9\4:\t:\4;\t;\4<\t<\4=\t="+
		"\4>\t>\4?\t?\4@\t@\4A\tA\4B\tB\4C\tC\4D\tD\4E\tE\3\2\3\2\3\3\3\3\3\3\3"+
		"\3\3\3\3\3\3\4\3\4\5\4\u0095\n\4\3\5\3\5\3\5\5\5\u009a\n\5\3\6\3\6\3\6"+
		"\3\6\3\6\3\6\3\7\3\7\5\7\u00a4\n\7\3\b\3\b\3\b\5\b\u00a9\n\b\3\t\3\t\3"+
		"\n\3\n\3\n\3\n\3\13\5\13\u00b2\n\13\3\13\3\13\5\13\u00b6\n\13\3\f\3\f"+
		"\5\f\u00ba\n\f\3\f\3\f\5\f\u00be\n\f\3\r\3\r\3\r\5\r\u00c3\n\r\3\r\5\r"+
		"\u00c6\n\r\3\16\3\16\3\16\3\16\5\16\u00cc\n\16\5\16\u00ce\n\16\3\17\3"+
		"\17\3\20\3\20\3\21\3\21\3\22\3\22\3\22\3\22\5\22\u00da\n\22\3\22\3\22"+
		"\3\23\3\23\3\23\3\23\3\23\3\24\3\24\3\24\5\24\u00e6\n\24\3\24\3\24\3\24"+
		"\3\25\3\25\3\25\3\26\3\26\5\26\u00f0\n\26\3\27\3\27\3\27\5\27\u00f5\n"+
		"\27\3\30\3\30\5\30\u00f9\n\30\3\30\3\30\3\31\3\31\5\31\u00ff\n\31\3\32"+
		"\3\32\3\32\5\32\u0104\n\32\3\33\3\33\5\33\u0108\n\33\3\34\3\34\5\34\u010c"+
		"\n\34\3\35\3\35\5\35\u0110\n\35\3\36\3\36\3\37\3\37\3\37\5\37\u0117\n"+
		"\37\3\37\3\37\3 \3 \3 \5 \u011e\n \3 \3 \5 \u0122\n \5 \u0124\n \3!\3"+
		"!\3!\3!\3\"\3\"\5\"\u012c\n\"\3\"\5\"\u012f\n\"\3\"\3\"\3#\3#\3#\5#\u0136"+
		"\n#\3#\5#\u0139\n#\3$\3$\3$\3%\3%\3%\3&\3&\3&\3\'\3\'\3\'\3\'\3\'\3\'"+
		"\3\'\3\'\3\'\3\'\3\'\5\'\u014f\n\'\3\'\3\'\3\'\5\'\u0154\n\'\3(\3(\3("+
		"\5(\u0159\n(\3(\5(\u015c\n(\3(\3(\3)\3)\3)\3)\3)\3*\3*\5*\u0167\n*\3+"+
		"\3+\5+\u016b\n+\3,\3,\3,\3,\3,\3,\3,\3,\3,\3,\3,\3,\3,\5,\u017a\n,\3-"+
		"\3-\3-\3-\3-\5-\u0181\n-\3-\3-\3.\3.\3.\3.\3.\3.\3.\3.\3.\3.\3.\5.\u0190"+
		"\n.\3/\3/\3/\3/\3/\3/\3/\3/\5/\u019a\n/\3\60\3\60\5\60\u019e\n\60\3\61"+
		"\3\61\3\61\5\61\u01a3\n\61\3\61\3\61\3\62\3\62\3\62\3\62\3\62\3\63\3\63"+
		"\5\63\u01ae\n\63\3\64\3\64\5\64\u01b2\n\64\3\64\3\64\3\65\3\65\5\65\u01b8"+
		"\n\65\3\66\3\66\3\66\3\66\3\67\3\67\3\67\3\67\38\38\38\38\38\38\38\38"+
		"\38\38\38\38\38\58\u01cf\n8\39\39\39\39\39\39\39\39\3:\3:\5:\u01db\n:"+
		"\3;\3;\3;\5;\u01e0\n;\3;\5;\u01e3\n;\3<\3<\3<\3<\5<\u01e9\n<\3<\5<\u01ec"+
		"\n<\3<\5<\u01ef\n<\3=\3=\3=\3=\5=\u01f5\n=\3=\5=\u01f8\n=\3=\5=\u01fb"+
		"\n=\3=\5=\u01fe\n=\3>\3>\3>\3?\3?\5?\u0205\n?\3@\3@\3@\3@\3@\3@\3@\3@"+
		"\3@\3@\3@\3@\5@\u0213\n@\3A\5A\u0216\nA\3B\3B\5B\u021a\nB\3B\3B\5B\u021e"+
		"\nB\5B\u0220\nB\3C\3C\5C\u0224\nC\3C\3C\3D\3D\5D\u022a\nD\3E\5E\u022d"+
		"\nE\3E\3E\5E\u0231\nE\3E\2\2F\2\4\6\b\n\f\16\20\22\24\26\30\32\34\36 "+
		"\"$&(*,.\60\62\64\668:<>@BDFHJLNPRTVXZ\\^`bdfhjlnprtvxz|~\u0080\u0082"+
		"\u0084\u0086\u0088\2\6\4\2##--\3\2,8\4\2\37\"9:\3\2\5\t\2\u024b\2\u008a"+
		"\3\2\2\2\4\u008c\3\2\2\2\6\u0092\3\2\2\2\b\u0096\3\2\2\2\n\u009b\3\2\2"+
		"\2\f\u00a1\3\2\2\2\16\u00a5\3\2\2\2\20\u00aa\3\2\2\2\22\u00ac\3\2\2\2"+
		"\24\u00b1\3\2\2\2\26\u00b7\3\2\2\2\30\u00c5\3\2\2\2\32\u00cd\3\2\2\2\34"+
		"\u00cf\3\2\2\2\36\u00d1\3\2\2\2 \u00d3\3\2\2\2\"\u00d5\3\2\2\2$\u00dd"+
		"\3\2\2\2&\u00e2\3\2\2\2(\u00ea\3\2\2\2*\u00ed\3\2\2\2,\u00f1\3\2\2\2."+
		"\u00f6\3\2\2\2\60\u00fc\3\2\2\2\62\u0100\3\2\2\2\64\u0107\3\2\2\2\66\u0109"+
		"\3\2\2\28\u010f\3\2\2\2:\u0111\3\2\2\2<\u0113\3\2\2\2>\u0123\3\2\2\2@"+
		"\u0125\3\2\2\2B\u0129\3\2\2\2D\u0132\3\2\2\2F\u013a\3\2\2\2H\u013d\3\2"+
		"\2\2J\u0140\3\2\2\2L\u0153\3\2\2\2N\u0155\3\2\2\2P\u015f\3\2\2\2R\u0164"+
		"\3\2\2\2T\u0168\3\2\2\2V\u0179\3\2\2\2X\u017b\3\2\2\2Z\u018f\3\2\2\2\\"+
		"\u0199\3\2\2\2^\u019b\3\2\2\2`\u019f\3\2\2\2b\u01a6\3\2\2\2d\u01ab\3\2"+
		"\2\2f\u01af\3\2\2\2h\u01b5\3\2\2\2j\u01b9\3\2\2\2l\u01bd\3\2\2\2n\u01ce"+
		"\3\2\2\2p\u01d0\3\2\2\2r\u01da\3\2\2\2t\u01dc\3\2\2\2v\u01e4\3\2\2\2x"+
		"\u01fd\3\2\2\2z\u01ff\3\2\2\2|\u0202\3\2\2\2~\u0212\3\2\2\2\u0080\u0215"+
		"\3\2\2\2\u0082\u021f\3\2\2\2\u0084\u0221\3\2\2\2\u0086\u0227\3\2\2\2\u0088"+
		"\u022c\3\2\2\2\u008a\u008b\5\u0088E\2\u008b\3\3\2\2\2\u008c\u008d\7\3"+
		"\2\2\u008d\u008e\7&\2\2\u008e\u008f\5\6\4\2\u008f\u0090\7\'\2\2\u0090"+
		"\u0091\7(\2\2\u0091\5\3\2\2\2\u0092\u0094\7=\2\2\u0093\u0095\5\b\5\2\u0094"+
		"\u0093\3\2\2\2\u0094\u0095\3\2\2\2\u0095\7\3\2\2\2\u0096\u0097\7)\2\2"+
		"\u0097\u0099\7=\2\2\u0098\u009a\5\b\5\2\u0099\u0098\3\2\2\2\u0099\u009a"+
		"\3\2\2\2\u009a\t\3\2\2\2\u009b\u009c\7\4\2\2\u009c\u009d\7&\2\2\u009d"+
		"\u009e\5\f\7\2\u009e\u009f\7\'\2\2\u009f\u00a0\7(\2\2\u00a0\13\3\2\2\2"+
		"\u00a1\u00a3\5\20\t\2\u00a2\u00a4\5\16\b\2\u00a3\u00a2\3\2\2\2\u00a3\u00a4"+
		"\3\2\2\2\u00a4\r\3\2\2\2\u00a5\u00a6\7*\2\2\u00a6\u00a8\5\24\13\2\u00a7"+
		"\u00a9\5\16\b\2\u00a8\u00a7\3\2\2\2\u00a8\u00a9\3\2\2\2\u00a9\17\3\2\2"+
		"\2\u00aa\u00ab\5\24\13\2\u00ab\21\3\2\2\2\u00ac\u00ad\7&\2\2\u00ad\u00ae"+
		"\5\24\13\2\u00ae\u00af\7\'\2\2\u00af\23\3\2\2\2\u00b0\u00b2\5\34\17\2"+
		"\u00b1\u00b0\3\2\2\2\u00b1\u00b2\3\2\2\2\u00b2\u00b3\3\2\2\2\u00b3\u00b5"+
		"\5\30\r\2\u00b4\u00b6\5\26\f\2\u00b5\u00b4\3\2\2\2\u00b5\u00b6\3\2\2\2"+
		"\u00b6\25\3\2\2\2\u00b7\u00b9\5\36\20\2\u00b8\u00ba\5\34\17\2\u00b9\u00b8"+
		"\3\2\2\2\u00b9\u00ba\3\2\2\2\u00ba\u00bb\3\2\2\2\u00bb\u00bd\5\30\r\2"+
		"\u00bc\u00be\5\26\f\2\u00bd\u00bc\3\2\2\2\u00bd\u00be\3\2\2\2\u00be\27"+
		"\3\2\2\2\u00bf\u00c6\5 \21\2\u00c0\u00c2\7=\2\2\u00c1\u00c3\5\32\16\2"+
		"\u00c2\u00c1\3\2\2\2\u00c2\u00c3\3\2\2\2\u00c3\u00c6\3\2\2\2\u00c4\u00c6"+
		"\5\22\n\2\u00c5\u00bf\3\2\2\2\u00c5\u00c0\3\2\2\2\u00c5\u00c4\3\2\2\2"+
		"\u00c6\31\3\2\2\2\u00c7\u00ce\5.\30\2\u00c8\u00c9\7)\2\2\u00c9\u00cb\7"+
		"=\2\2\u00ca\u00cc\5\b\5\2\u00cb\u00ca\3\2\2\2\u00cb\u00cc\3\2\2\2\u00cc"+
		"\u00ce\3\2\2\2\u00cd\u00c7\3\2\2\2\u00cd\u00c8\3\2\2\2\u00ce\33\3\2\2"+
		"\2\u00cf\u00d0\t\2\2\2\u00d0\35\3\2\2\2\u00d1\u00d2\t\3\2\2\u00d2\37\3"+
		"\2\2\2\u00d3\u00d4\t\4\2\2\u00d4!\3\2\2\2\u00d5\u00d6\7\16\2\2\u00d6\u00d7"+
		"\58\35\2\u00d7\u00d9\5&\24\2\u00d8\u00da\5\66\34\2\u00d9\u00d8\3\2\2\2"+
		"\u00d9\u00da\3\2\2\2\u00da\u00db\3\2\2\2\u00db\u00dc\5$\23\2\u00dc#\3"+
		"\2\2\2\u00dd\u00de\7\17\2\2\u00de\u00df\5\24\13\2\u00df\u00e0\7(\2\2\u00e0"+
		"\u00e1\7\20\2\2\u00e1%\3\2\2\2\u00e2\u00e3\7=\2\2\u00e3\u00e5\7&\2\2\u00e4"+
		"\u00e6\5*\26\2\u00e5\u00e4\3\2\2\2\u00e5\u00e6\3\2\2\2\u00e6\u00e7\3\2"+
		"\2\2\u00e7\u00e8\7\'\2\2\u00e8\u00e9\7\30\2\2\u00e9\'\3\2\2\2\u00ea\u00eb"+
		"\58\35\2\u00eb\u00ec\7=\2\2\u00ec)\3\2\2\2\u00ed\u00ef\5(\25\2\u00ee\u00f0"+
		"\5,\27\2\u00ef\u00ee\3\2\2\2\u00ef\u00f0\3\2\2\2\u00f0+\3\2\2\2\u00f1"+
		"\u00f2\7*\2\2\u00f2\u00f4\5(\25\2\u00f3\u00f5\5,\27\2\u00f4\u00f3\3\2"+
		"\2\2\u00f4\u00f5\3\2\2\2\u00f5-\3\2\2\2\u00f6\u00f8\7&\2\2\u00f7\u00f9"+
		"\5\60\31\2\u00f8\u00f7\3\2\2\2\u00f8\u00f9\3\2\2\2\u00f9\u00fa\3\2\2\2"+
		"\u00fa\u00fb\7\'\2\2\u00fb/\3\2\2\2\u00fc\u00fe\5\64\33\2\u00fd\u00ff"+
		"\5\62\32\2\u00fe\u00fd\3\2\2\2\u00fe\u00ff\3\2\2\2\u00ff\61\3\2\2\2\u0100"+
		"\u0101\7*\2\2\u0101\u0103\5\64\33\2\u0102\u0104\5\62\32\2\u0103\u0102"+
		"\3\2\2\2\u0103\u0104\3\2\2\2\u0104\63\3\2\2\2\u0105\u0108\5 \21\2\u0106"+
		"\u0108\7=\2\2\u0107\u0105\3\2\2\2\u0107\u0106\3\2\2\2\u0108\65\3\2\2\2"+
		"\u0109\u010b\5V,\2\u010a\u010c\5\66\34\2\u010b\u010a\3\2\2\2\u010b\u010c"+
		"\3\2\2\2\u010c\67\3\2\2\2\u010d\u0110\5:\36\2\u010e\u0110\7=\2\2\u010f"+
		"\u010d\3\2\2\2\u010f\u010e\3\2\2\2\u01109\3\2\2\2\u0111\u0112\t\5\2\2"+
		"\u0112;\3\2\2\2\u0113\u0114\7\24\2\2\u0114\u0116\7=\2\2\u0115\u0117\5"+
		"> \2\u0116\u0115\3\2\2\2\u0116\u0117\3\2\2\2\u0117\u0118\3\2\2\2\u0118"+
		"\u0119\7\25\2\2\u0119=\3\2\2\2\u011a\u011b\5:\36\2\u011b\u011d\5B\"\2"+
		"\u011c\u011e\5> \2\u011d\u011c\3\2\2\2\u011d\u011e\3\2\2\2\u011e\u0124"+
		"\3\2\2\2\u011f\u0121\5@!\2\u0120\u0122\5> \2\u0121\u0120\3\2\2\2\u0121"+
		"\u0122\3\2\2\2\u0122\u0124\3\2\2\2\u0123\u011a\3\2\2\2\u0123\u011f\3\2"+
		"\2\2\u0124?\3\2\2\2\u0125\u0126\7=\2\2\u0126\u0127\7=\2\2\u0127\u0128"+
		"\7(\2\2\u0128A\3\2\2\2\u0129\u012b\7=\2\2\u012a\u012c\5F$\2\u012b\u012a"+
		"\3\2\2\2\u012b\u012c\3\2\2\2\u012c\u012e\3\2\2\2\u012d\u012f\5D#\2\u012e"+
		"\u012d\3\2\2\2\u012e\u012f\3\2\2\2\u012f\u0130\3\2\2\2\u0130\u0131\7("+
		"\2\2\u0131C\3\2\2\2\u0132\u0133\7*\2\2\u0133\u0135\7=\2\2\u0134\u0136"+
		"\5F$\2\u0135\u0134\3\2\2\2\u0135\u0136\3\2\2\2\u0136\u0138\3\2\2\2\u0137"+
		"\u0139\5D#\2\u0138\u0137\3\2\2\2\u0138\u0139\3\2\2\2\u0139E\3\2\2\2\u013a"+
		"\u013b\7+\2\2\u013b\u013c\5\24\13\2\u013cG\3\2\2\2\u013d\u013e\7+\2\2"+
		"\u013e\u013f\5\24\13\2\u013fI\3\2\2\2\u0140\u0141\7=\2\2\u0141\u0142\5"+
		"L\'\2\u0142K\3\2\2\2\u0143\u0144\7=\2\2\u0144\u0154\7(\2\2\u0145\u0146"+
		"\5H%\2\u0146\u0147\7(\2\2\u0147\u0154\3\2\2\2\u0148\u0149\5.\30\2\u0149"+
		"\u014a\7(\2\2\u014a\u0154\3\2\2\2\u014b\u014c\7)\2\2\u014c\u014e\7=\2"+
		"\2\u014d\u014f\5\b\5\2\u014e\u014d\3\2\2\2\u014e\u014f\3\2\2\2\u014f\u0150"+
		"\3\2\2\2\u0150\u0151\5H%\2\u0151\u0152\7(\2\2\u0152\u0154\3\2\2\2\u0153"+
		"\u0143\3\2\2\2\u0153\u0145\3\2\2\2\u0153\u0148\3\2\2\2\u0153\u014b\3\2"+
		"\2\2\u0154M\3\2\2\2\u0155\u0156\7\n\2\2\u0156\u0158\5P)\2\u0157\u0159"+
		"\5T+\2\u0158\u0157\3\2\2\2\u0158\u0159\3\2\2\2\u0159\u015b\3\2\2\2\u015a"+
		"\u015c\5R*\2\u015b\u015a\3\2\2\2\u015b\u015c\3\2\2\2\u015c\u015d\3\2\2"+
		"\2\u015d\u015e\7\13\2\2\u015eO\3\2\2\2\u015f\u0160\7&\2\2\u0160\u0161"+
		"\5\24\13\2\u0161\u0162\7\'\2\2\u0162\u0163\7\f\2\2\u0163Q\3\2\2\2\u0164"+
		"\u0166\7\r\2\2\u0165\u0167\5T+\2\u0166\u0165\3\2\2\2\u0166\u0167\3\2\2"+
		"\2\u0167S\3\2\2\2\u0168\u016a\5V,\2\u0169\u016b\5T+\2\u016a\u0169\3\2"+
		"\2\2\u016a\u016b\3\2\2\2\u016bU\3\2\2\2\u016c\u017a\5J&\2\u016d\u017a"+
		"\5\4\3\2\u016e\u017a\5\n\6\2\u016f\u0170\5:\36\2\u0170\u0171\5B\"\2\u0171"+
		"\u017a\3\2\2\2\u0172\u017a\5N(\2\u0173\u017a\5X-\2\u0174\u017a\5f\64\2"+
		"\u0175\u017a\5`\61\2\u0176\u017a\5p9\2\u0177\u0178\7\21\2\2\u0178\u017a"+
		"\7(\2\2\u0179\u016c\3\2\2\2\u0179\u016d\3\2\2\2\u0179\u016e\3\2\2\2\u0179"+
		"\u016f\3\2\2\2\u0179\u0172\3\2\2\2\u0179\u0173\3\2\2\2\u0179\u0174\3\2"+
		"\2\2\u0179\u0175\3\2\2\2\u0179\u0176\3\2\2\2\u0179\u0177\3\2\2\2\u017a"+
		"W\3\2\2\2\u017b\u017c\7\22\2\2\u017c\u017d\7&\2\2\u017d\u017e\5Z.\2\u017e"+
		"\u0180\5\\/\2\u017f\u0181\5^\60\2\u0180\u017f\3\2\2\2\u0180\u0181\3\2"+
		"\2\2\u0181\u0182\3\2\2\2\u0182\u0183\7\23\2\2\u0183Y\3\2\2\2\u0184\u0185"+
		"\7\7\2\2\u0185\u0186\7=\2\2\u0186\u0187\7+\2\2\u0187\u0188\7 \2\2\u0188"+
		"\u0189\7(\2\2\u0189\u0190\5\24\13\2\u018a\u018b\7=\2\2\u018b\u018c\7+"+
		"\2\2\u018c\u018d\7 \2\2\u018d\u018e\7(\2\2\u018e\u0190\5\24\13\2\u018f"+
		"\u0184\3\2\2\2\u018f\u018a\3\2\2\2\u0190[\3\2\2\2\u0191\u0192\7(\2\2\u0192"+
		"\u0193\7=\2\2\u0193\u0194\7\'\2\2\u0194\u019a\7\30\2\2\u0195\u0196\7("+
		"\2\2\u0196\u0197\7 \2\2\u0197\u0198\7\'\2\2\u0198\u019a\7\30\2\2\u0199"+
		"\u0191\3\2\2\2\u0199\u0195\3\2\2\2\u019a]\3\2\2\2\u019b\u019d\5V,\2\u019c"+
		"\u019e\5^\60\2\u019d\u019c\3\2\2\2\u019d\u019e\3\2\2\2\u019e_\3\2\2\2"+
		"\u019f\u01a0\7\26\2\2\u01a0\u01a2\5b\62\2\u01a1\u01a3\5d\63\2\u01a2\u01a1"+
		"\3\2\2\2\u01a2\u01a3\3\2\2\2\u01a3\u01a4\3\2\2\2\u01a4\u01a5\7\27\2\2"+
		"\u01a5a\3\2\2\2\u01a6\u01a7\7&\2\2\u01a7\u01a8\5\24\13\2\u01a8\u01a9\7"+
		"\'\2\2\u01a9\u01aa\7\30\2\2\u01aac\3\2\2\2\u01ab\u01ad\5V,\2\u01ac\u01ae"+
		"\5d\63\2\u01ad\u01ac\3\2\2\2\u01ad\u01ae\3\2\2\2\u01aee\3\2\2\2\u01af"+
		"\u01b1\7\30\2\2\u01b0\u01b2\5h\65\2\u01b1\u01b0\3\2\2\2\u01b1\u01b2\3"+
		"\2\2\2\u01b2\u01b3\3\2\2\2\u01b3\u01b4\5j\66\2\u01b4g\3\2\2\2\u01b5\u01b7"+
		"\5n8\2\u01b6\u01b8\5h\65\2\u01b7\u01b6\3\2\2\2\u01b7\u01b8\3\2\2\2\u01b8"+
		"i\3\2\2\2\u01b9\u01ba\7\26\2\2\u01ba\u01bb\5l\67\2\u01bb\u01bc\7(\2\2"+
		"\u01bck\3\2\2\2\u01bd\u01be\7&\2\2\u01be\u01bf\5\24\13\2\u01bf\u01c0\7"+
		"\'\2\2\u01c0m\3\2\2\2\u01c1\u01cf\5J&\2\u01c2\u01cf\5\n\6\2\u01c3\u01cf"+
		"\5\4\3\2\u01c4\u01c5\5:\36\2\u01c5\u01c6\5B\"\2\u01c6\u01cf\3\2\2\2\u01c7"+
		"\u01cf\5N(\2\u01c8\u01cf\5X-\2\u01c9\u01cf\5f\64\2\u01ca\u01cf\5`\61\2"+
		"\u01cb\u01cf\5p9\2\u01cc\u01cd\7\21\2\2\u01cd\u01cf\7(\2\2\u01ce\u01c1"+
		"\3\2\2\2\u01ce\u01c2\3\2\2\2\u01ce\u01c3\3\2\2\2\u01ce\u01c4\3\2\2\2\u01ce"+
		"\u01c7\3\2\2\2\u01ce\u01c8\3\2\2\2\u01ce\u01c9\3\2\2\2\u01ce\u01ca\3\2"+
		"\2\2\u01ce\u01cb\3\2\2\2\u01ce\u01cc\3\2\2\2\u01cfo\3\2\2\2\u01d0\u01d1"+
		"\7\31\2\2\u01d1\u01d2\7&\2\2\u01d2\u01d3\7=\2\2\u01d3\u01d4\7\'\2\2\u01d4"+
		"\u01d5\7\32\2\2\u01d5\u01d6\5r:\2\u01d6\u01d7\7\33\2\2\u01d7q\3\2\2\2"+
		"\u01d8\u01db\5t;\2\u01d9\u01db\5v<\2\u01da\u01d8\3\2\2\2\u01da\u01d9\3"+
		"\2\2\2\u01dbs\3\2\2\2\u01dc\u01dd\7\34\2\2\u01dd\u01df\7\35\2\2\u01de"+
		"\u01e0\5|?\2\u01df\u01de\3\2\2\2\u01df\u01e0\3\2\2\2\u01e0\u01e2\3\2\2"+
		"\2\u01e1\u01e3\5z>\2\u01e2\u01e1\3\2\2\2\u01e2\u01e3\3\2\2\2\u01e3u\3"+
		"\2\2\2\u01e4\u01e5\7\36\2\2\u01e5\u01e6\7 \2\2\u01e6\u01e8\7\35\2\2\u01e7"+
		"\u01e9\5|?\2\u01e8\u01e7\3\2\2\2\u01e8\u01e9\3\2\2\2\u01e9\u01eb\3\2\2"+
		"\2\u01ea\u01ec\5z>\2\u01eb\u01ea\3\2\2\2\u01eb\u01ec\3\2\2\2\u01ec\u01ee"+
		"\3\2\2\2\u01ed\u01ef\5x=\2\u01ee\u01ed\3\2\2\2\u01ee\u01ef\3\2\2\2\u01ef"+
		"w\3\2\2\2\u01f0\u01f1\7\36\2\2\u01f1\u01f2\7 \2\2\u01f2\u01f4\7\35\2\2"+
		"\u01f3\u01f5\5|?\2\u01f4\u01f3\3\2\2\2\u01f4\u01f5\3\2\2\2\u01f5\u01f7"+
		"\3\2\2\2\u01f6\u01f8\5z>\2\u01f7\u01f6\3\2\2\2\u01f7\u01f8\3\2\2\2\u01f8"+
		"\u01fa\3\2\2\2\u01f9\u01fb\5x=\2\u01fa\u01f9\3\2\2\2\u01fa\u01fb\3\2\2"+
		"\2\u01fb\u01fe\3\2\2\2\u01fc\u01fe\5t;\2\u01fd\u01f0\3\2\2\2\u01fd\u01fc"+
		"\3\2\2\2\u01fey\3\2\2\2\u01ff\u0200\7\21\2\2\u0200\u0201\7(\2\2\u0201"+
		"{\3\2\2\2\u0202\u0204\5~@\2\u0203\u0205\5|?\2\u0204\u0203\3\2\2\2\u0204"+
		"\u0205\3\2\2\2\u0205}\3\2\2\2\u0206\u0213\5J&\2\u0207\u0213\5\n\6\2\u0208"+
		"\u0213\5\4\3\2\u0209\u0213\5\n\6\2\u020a\u020b\5:\36\2\u020b\u020c\5B"+
		"\"\2\u020c\u0213\3\2\2\2\u020d\u0213\5N(\2\u020e\u0213\5X-\2\u020f\u0213"+
		"\5f\64\2\u0210\u0213\5`\61\2\u0211\u0213\5p9\2\u0212\u0206\3\2\2\2\u0212"+
		"\u0207\3\2\2\2\u0212\u0208\3\2\2\2\u0212\u0209\3\2\2\2\u0212\u020a\3\2"+
		"\2\2\u0212\u020d\3\2\2\2\u0212\u020e\3\2\2\2\u0212\u020f\3\2\2\2\u0212"+
		"\u0210\3\2\2\2\u0212\u0211\3\2\2\2\u0213\177\3\2\2\2\u0214\u0216\5\u0082"+
		"B\2\u0215\u0214\3\2\2\2\u0215\u0216\3\2\2\2\u0216\u0081\3\2\2\2\u0217"+
		"\u0219\5<\37\2\u0218\u021a\5\u0082B\2\u0219\u0218\3\2\2\2\u0219\u021a"+
		"\3\2\2\2\u021a\u0220\3\2\2\2\u021b\u021d\5\"\22\2\u021c\u021e\5\u0082"+
		"B\2\u021d\u021c\3\2\2\2\u021d\u021e\3\2\2\2\u021e\u0220\3\2\2\2\u021f"+
		"\u0217\3\2\2\2\u021f\u021b\3\2\2\2\u0220\u0083\3\2\2\2\u0221\u0223\7$"+
		"\2\2\u0222\u0224\5\u0086D\2\u0223\u0222\3\2\2\2\u0223\u0224\3\2\2\2\u0224"+
		"\u0225\3\2\2\2\u0225\u0226\7%\2\2\u0226\u0085\3\2\2\2\u0227\u0229\5V,"+
		"\2\u0228\u022a\5\u0086D\2\u0229\u0228\3\2\2\2\u0229\u022a\3\2\2\2\u022a"+
		"\u0087\3\2\2\2\u022b\u022d\5\u0080A\2\u022c\u022b\3\2\2\2\u022c\u022d"+
		"\3\2\2\2\u022d\u022e\3\2\2\2\u022e\u0230\5\u0084C\2\u022f\u0231\5\u0080"+
		"A\2\u0230\u022f\3\2\2\2\u0230\u0231\3\2\2\2\u0231\u0089\3\2\2\2D\u0094"+
		"\u0099\u00a3\u00a8\u00b1\u00b5\u00b9\u00bd\u00c2\u00c5\u00cb\u00cd\u00d9"+
		"\u00e5\u00ef\u00f4\u00f8\u00fe\u0103\u0107\u010b\u010f\u0116\u011d\u0121"+
		"\u0123\u012b\u012e\u0135\u0138\u014e\u0153\u0158\u015b\u0166\u016a\u0179"+
		"\u0180\u018f\u0199\u019d\u01a2\u01ad\u01b1\u01b7\u01ce\u01da\u01df\u01e2"+
		"\u01e8\u01eb\u01ee\u01f4\u01f7\u01fa\u01fd\u0204\u0212\u0215\u0219\u021d"+
		"\u021f\u0223\u0229\u022c\u0230";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}