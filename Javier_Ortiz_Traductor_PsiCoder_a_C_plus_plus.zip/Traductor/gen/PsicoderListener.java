// Generated from C:/Users/Alejandro Ortiz/IdeaProjects/Traductor/grammar\Psicoder.g4 by ANTLR 4.9.1
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link PsicoderParser}.
 */
public interface PsicoderListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#init}.
	 * @param ctx the parse tree
	 */
	void enterInit(PsicoderParser.InitContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#init}.
	 * @param ctx the parse tree
	 */
	void exitInit(PsicoderParser.InitContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#lectura}.
	 * @param ctx the parse tree
	 */
	void enterLectura(PsicoderParser.LecturaContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#lectura}.
	 * @param ctx the parse tree
	 */
	void exitLectura(PsicoderParser.LecturaContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#atributo_o_variable}.
	 * @param ctx the parse tree
	 */
	void enterAtributo_o_variable(PsicoderParser.Atributo_o_variableContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#atributo_o_variable}.
	 * @param ctx the parse tree
	 */
	void exitAtributo_o_variable(PsicoderParser.Atributo_o_variableContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#getters}.
	 * @param ctx the parse tree
	 */
	void enterGetters(PsicoderParser.GettersContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#getters}.
	 * @param ctx the parse tree
	 */
	void exitGetters(PsicoderParser.GettersContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#impresion}.
	 * @param ctx the parse tree
	 */
	void enterImpresion(PsicoderParser.ImpresionContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#impresion}.
	 * @param ctx the parse tree
	 */
	void exitImpresion(PsicoderParser.ImpresionContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#parametros_impresion}.
	 * @param ctx the parse tree
	 */
	void enterParametros_impresion(PsicoderParser.Parametros_impresionContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#parametros_impresion}.
	 * @param ctx the parse tree
	 */
	void exitParametros_impresion(PsicoderParser.Parametros_impresionContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#parametros_impresion_2_a_n}.
	 * @param ctx the parse tree
	 */
	void enterParametros_impresion_2_a_n(PsicoderParser.Parametros_impresion_2_a_nContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#parametros_impresion_2_a_n}.
	 * @param ctx the parse tree
	 */
	void exitParametros_impresion_2_a_n(PsicoderParser.Parametros_impresion_2_a_nContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#parametro_1_impresion}.
	 * @param ctx the parse tree
	 */
	void enterParametro_1_impresion(PsicoderParser.Parametro_1_impresionContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#parametro_1_impresion}.
	 * @param ctx the parse tree
	 */
	void exitParametro_1_impresion(PsicoderParser.Parametro_1_impresionContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#expresion_entre_parentesis}.
	 * @param ctx the parse tree
	 */
	void enterExpresion_entre_parentesis(PsicoderParser.Expresion_entre_parentesisContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#expresion_entre_parentesis}.
	 * @param ctx the parse tree
	 */
	void exitExpresion_entre_parentesis(PsicoderParser.Expresion_entre_parentesisContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#expresion}.
	 * @param ctx the parse tree
	 */
	void enterExpresion(PsicoderParser.ExpresionContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#expresion}.
	 * @param ctx the parse tree
	 */
	void exitExpresion(PsicoderParser.ExpresionContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#expresion_2_a_n}.
	 * @param ctx the parse tree
	 */
	void enterExpresion_2_a_n(PsicoderParser.Expresion_2_a_nContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#expresion_2_a_n}.
	 * @param ctx the parse tree
	 */
	void exitExpresion_2_a_n(PsicoderParser.Expresion_2_a_nContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#elemento_para_operacion}.
	 * @param ctx the parse tree
	 */
	void enterElemento_para_operacion(PsicoderParser.Elemento_para_operacionContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#elemento_para_operacion}.
	 * @param ctx the parse tree
	 */
	void exitElemento_para_operacion(PsicoderParser.Elemento_para_operacionContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#posible_funcion_o_atributo}.
	 * @param ctx the parse tree
	 */
	void enterPosible_funcion_o_atributo(PsicoderParser.Posible_funcion_o_atributoContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#posible_funcion_o_atributo}.
	 * @param ctx the parse tree
	 */
	void exitPosible_funcion_o_atributo(PsicoderParser.Posible_funcion_o_atributoContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#posible_negacion_o_cambio_de_signo}.
	 * @param ctx the parse tree
	 */
	void enterPosible_negacion_o_cambio_de_signo(PsicoderParser.Posible_negacion_o_cambio_de_signoContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#posible_negacion_o_cambio_de_signo}.
	 * @param ctx the parse tree
	 */
	void exitPosible_negacion_o_cambio_de_signo(PsicoderParser.Posible_negacion_o_cambio_de_signoContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#operacion}.
	 * @param ctx the parse tree
	 */
	void enterOperacion(PsicoderParser.OperacionContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#operacion}.
	 * @param ctx the parse tree
	 */
	void exitOperacion(PsicoderParser.OperacionContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#dato}.
	 * @param ctx the parse tree
	 */
	void enterDato(PsicoderParser.DatoContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#dato}.
	 * @param ctx the parse tree
	 */
	void exitDato(PsicoderParser.DatoContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#funcion}.
	 * @param ctx the parse tree
	 */
	void enterFuncion(PsicoderParser.FuncionContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#funcion}.
	 * @param ctx the parse tree
	 */
	void exitFuncion(PsicoderParser.FuncionContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#retorno_de_la_funcion}.
	 * @param ctx the parse tree
	 */
	void enterRetorno_de_la_funcion(PsicoderParser.Retorno_de_la_funcionContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#retorno_de_la_funcion}.
	 * @param ctx the parse tree
	 */
	void exitRetorno_de_la_funcion(PsicoderParser.Retorno_de_la_funcionContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#operandos_funcion}.
	 * @param ctx the parse tree
	 */
	void enterOperandos_funcion(PsicoderParser.Operandos_funcionContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#operandos_funcion}.
	 * @param ctx the parse tree
	 */
	void exitOperandos_funcion(PsicoderParser.Operandos_funcionContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#parametro_i_funcion}.
	 * @param ctx the parse tree
	 */
	void enterParametro_i_funcion(PsicoderParser.Parametro_i_funcionContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#parametro_i_funcion}.
	 * @param ctx the parse tree
	 */
	void exitParametro_i_funcion(PsicoderParser.Parametro_i_funcionContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#parametros_funcion}.
	 * @param ctx the parse tree
	 */
	void enterParametros_funcion(PsicoderParser.Parametros_funcionContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#parametros_funcion}.
	 * @param ctx the parse tree
	 */
	void exitParametros_funcion(PsicoderParser.Parametros_funcionContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#parametros_funcion_2_a_n}.
	 * @param ctx the parse tree
	 */
	void enterParametros_funcion_2_a_n(PsicoderParser.Parametros_funcion_2_a_nContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#parametros_funcion_2_a_n}.
	 * @param ctx the parse tree
	 */
	void exitParametros_funcion_2_a_n(PsicoderParser.Parametros_funcion_2_a_nContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#llamada_a_funcion}.
	 * @param ctx the parse tree
	 */
	void enterLlamada_a_funcion(PsicoderParser.Llamada_a_funcionContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#llamada_a_funcion}.
	 * @param ctx the parse tree
	 */
	void exitLlamada_a_funcion(PsicoderParser.Llamada_a_funcionContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#parametros_llamada_a_funcion}.
	 * @param ctx the parse tree
	 */
	void enterParametros_llamada_a_funcion(PsicoderParser.Parametros_llamada_a_funcionContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#parametros_llamada_a_funcion}.
	 * @param ctx the parse tree
	 */
	void exitParametros_llamada_a_funcion(PsicoderParser.Parametros_llamada_a_funcionContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#parametros_llamada_a_funcion_2_a_n}.
	 * @param ctx the parse tree
	 */
	void enterParametros_llamada_a_funcion_2_a_n(PsicoderParser.Parametros_llamada_a_funcion_2_a_nContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#parametros_llamada_a_funcion_2_a_n}.
	 * @param ctx the parse tree
	 */
	void exitParametros_llamada_a_funcion_2_a_n(PsicoderParser.Parametros_llamada_a_funcion_2_a_nContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#parametro_llamada_a_funcion}.
	 * @param ctx the parse tree
	 */
	void enterParametro_llamada_a_funcion(PsicoderParser.Parametro_llamada_a_funcionContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#parametro_llamada_a_funcion}.
	 * @param ctx the parse tree
	 */
	void exitParametro_llamada_a_funcion(PsicoderParser.Parametro_llamada_a_funcionContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#acciones_cuerpo_funcion}.
	 * @param ctx the parse tree
	 */
	void enterAcciones_cuerpo_funcion(PsicoderParser.Acciones_cuerpo_funcionContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#acciones_cuerpo_funcion}.
	 * @param ctx the parse tree
	 */
	void exitAcciones_cuerpo_funcion(PsicoderParser.Acciones_cuerpo_funcionContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#tipo_salida_funcion}.
	 * @param ctx the parse tree
	 */
	void enterTipo_salida_funcion(PsicoderParser.Tipo_salida_funcionContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#tipo_salida_funcion}.
	 * @param ctx the parse tree
	 */
	void exitTipo_salida_funcion(PsicoderParser.Tipo_salida_funcionContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#tipo}.
	 * @param ctx the parse tree
	 */
	void enterTipo(PsicoderParser.TipoContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#tipo}.
	 * @param ctx the parse tree
	 */
	void exitTipo(PsicoderParser.TipoContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#estructura}.
	 * @param ctx the parse tree
	 */
	void enterEstructura(PsicoderParser.EstructuraContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#estructura}.
	 * @param ctx the parse tree
	 */
	void exitEstructura(PsicoderParser.EstructuraContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#declaraciones_1_a_n}.
	 * @param ctx the parse tree
	 */
	void enterDeclaraciones_1_a_n(PsicoderParser.Declaraciones_1_a_nContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#declaraciones_1_a_n}.
	 * @param ctx the parse tree
	 */
	void exitDeclaraciones_1_a_n(PsicoderParser.Declaraciones_1_a_nContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#declaracion_instancia_objeto}.
	 * @param ctx the parse tree
	 */
	void enterDeclaracion_instancia_objeto(PsicoderParser.Declaracion_instancia_objetoContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#declaracion_instancia_objeto}.
	 * @param ctx the parse tree
	 */
	void exitDeclaracion_instancia_objeto(PsicoderParser.Declaracion_instancia_objetoContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#declaracion}.
	 * @param ctx the parse tree
	 */
	void enterDeclaracion(PsicoderParser.DeclaracionContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#declaracion}.
	 * @param ctx the parse tree
	 */
	void exitDeclaracion(PsicoderParser.DeclaracionContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#variables_2_a_n}.
	 * @param ctx the parse tree
	 */
	void enterVariables_2_a_n(PsicoderParser.Variables_2_a_nContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#variables_2_a_n}.
	 * @param ctx the parse tree
	 */
	void exitVariables_2_a_n(PsicoderParser.Variables_2_a_nContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#inicializacion_variable}.
	 * @param ctx the parse tree
	 */
	void enterInicializacion_variable(PsicoderParser.Inicializacion_variableContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#inicializacion_variable}.
	 * @param ctx the parse tree
	 */
	void exitInicializacion_variable(PsicoderParser.Inicializacion_variableContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#asignacion}.
	 * @param ctx the parse tree
	 */
	void enterAsignacion(PsicoderParser.AsignacionContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#asignacion}.
	 * @param ctx the parse tree
	 */
	void exitAsignacion(PsicoderParser.AsignacionContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#gestor_id}.
	 * @param ctx the parse tree
	 */
	void enterGestor_id(PsicoderParser.Gestor_idContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#gestor_id}.
	 * @param ctx the parse tree
	 */
	void exitGestor_id(PsicoderParser.Gestor_idContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#variable_o_objeto_o_funcion}.
	 * @param ctx the parse tree
	 */
	void enterVariable_o_objeto_o_funcion(PsicoderParser.Variable_o_objeto_o_funcionContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#variable_o_objeto_o_funcion}.
	 * @param ctx the parse tree
	 */
	void exitVariable_o_objeto_o_funcion(PsicoderParser.Variable_o_objeto_o_funcionContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#condicional}.
	 * @param ctx the parse tree
	 */
	void enterCondicional(PsicoderParser.CondicionalContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#condicional}.
	 * @param ctx the parse tree
	 */
	void exitCondicional(PsicoderParser.CondicionalContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#condicion_a_evaluar}.
	 * @param ctx the parse tree
	 */
	void enterCondicion_a_evaluar(PsicoderParser.Condicion_a_evaluarContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#condicion_a_evaluar}.
	 * @param ctx the parse tree
	 */
	void exitCondicion_a_evaluar(PsicoderParser.Condicion_a_evaluarContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#alternativa}.
	 * @param ctx the parse tree
	 */
	void enterAlternativa(PsicoderParser.AlternativaContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#alternativa}.
	 * @param ctx the parse tree
	 */
	void exitAlternativa(PsicoderParser.AlternativaContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#acciones_condicional}.
	 * @param ctx the parse tree
	 */
	void enterAcciones_condicional(PsicoderParser.Acciones_condicionalContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#acciones_condicional}.
	 * @param ctx the parse tree
	 */
	void exitAcciones_condicional(PsicoderParser.Acciones_condicionalContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#accion}.
	 * @param ctx the parse tree
	 */
	void enterAccion(PsicoderParser.AccionContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#accion}.
	 * @param ctx the parse tree
	 */
	void exitAccion(PsicoderParser.AccionContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#ciclo_para}.
	 * @param ctx the parse tree
	 */
	void enterCiclo_para(PsicoderParser.Ciclo_paraContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#ciclo_para}.
	 * @param ctx the parse tree
	 */
	void exitCiclo_para(PsicoderParser.Ciclo_paraContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#inicializacion_ciclo_para}.
	 * @param ctx the parse tree
	 */
	void enterInicializacion_ciclo_para(PsicoderParser.Inicializacion_ciclo_paraContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#inicializacion_ciclo_para}.
	 * @param ctx the parse tree
	 */
	void exitInicializacion_ciclo_para(PsicoderParser.Inicializacion_ciclo_paraContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#paso}.
	 * @param ctx the parse tree
	 */
	void enterPaso(PsicoderParser.PasoContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#paso}.
	 * @param ctx the parse tree
	 */
	void exitPaso(PsicoderParser.PasoContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#acciones_ciclo_para}.
	 * @param ctx the parse tree
	 */
	void enterAcciones_ciclo_para(PsicoderParser.Acciones_ciclo_paraContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#acciones_ciclo_para}.
	 * @param ctx the parse tree
	 */
	void exitAcciones_ciclo_para(PsicoderParser.Acciones_ciclo_paraContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#ciclo_mientras}.
	 * @param ctx the parse tree
	 */
	void enterCiclo_mientras(PsicoderParser.Ciclo_mientrasContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#ciclo_mientras}.
	 * @param ctx the parse tree
	 */
	void exitCiclo_mientras(PsicoderParser.Ciclo_mientrasContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#condicion_mientras}.
	 * @param ctx the parse tree
	 */
	void enterCondicion_mientras(PsicoderParser.Condicion_mientrasContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#condicion_mientras}.
	 * @param ctx the parse tree
	 */
	void exitCondicion_mientras(PsicoderParser.Condicion_mientrasContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#acciones_mientras}.
	 * @param ctx the parse tree
	 */
	void enterAcciones_mientras(PsicoderParser.Acciones_mientrasContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#acciones_mientras}.
	 * @param ctx the parse tree
	 */
	void exitAcciones_mientras(PsicoderParser.Acciones_mientrasContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#ciclo_hacer_mientras}.
	 * @param ctx the parse tree
	 */
	void enterCiclo_hacer_mientras(PsicoderParser.Ciclo_hacer_mientrasContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#ciclo_hacer_mientras}.
	 * @param ctx the parse tree
	 */
	void exitCiclo_hacer_mientras(PsicoderParser.Ciclo_hacer_mientrasContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#acciones_hacer_mientras}.
	 * @param ctx the parse tree
	 */
	void enterAcciones_hacer_mientras(PsicoderParser.Acciones_hacer_mientrasContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#acciones_hacer_mientras}.
	 * @param ctx the parse tree
	 */
	void exitAcciones_hacer_mientras(PsicoderParser.Acciones_hacer_mientrasContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#clausula_mientras}.
	 * @param ctx the parse tree
	 */
	void enterClausula_mientras(PsicoderParser.Clausula_mientrasContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#clausula_mientras}.
	 * @param ctx the parse tree
	 */
	void exitClausula_mientras(PsicoderParser.Clausula_mientrasContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#condicion_clausula_mientras}.
	 * @param ctx the parse tree
	 */
	void enterCondicion_clausula_mientras(PsicoderParser.Condicion_clausula_mientrasContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#condicion_clausula_mientras}.
	 * @param ctx the parse tree
	 */
	void exitCondicion_clausula_mientras(PsicoderParser.Condicion_clausula_mientrasContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#accion_chm}.
	 * @param ctx the parse tree
	 */
	void enterAccion_chm(PsicoderParser.Accion_chmContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#accion_chm}.
	 * @param ctx the parse tree
	 */
	void exitAccion_chm(PsicoderParser.Accion_chmContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#comando_seleccion}.
	 * @param ctx the parse tree
	 */
	void enterComando_seleccion(PsicoderParser.Comando_seleccionContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#comando_seleccion}.
	 * @param ctx the parse tree
	 */
	void exitComando_seleccion(PsicoderParser.Comando_seleccionContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#casos}.
	 * @param ctx the parse tree
	 */
	void enterCasos(PsicoderParser.CasosContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#casos}.
	 * @param ctx the parse tree
	 */
	void exitCasos(PsicoderParser.CasosContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#caso_defecto}.
	 * @param ctx the parse tree
	 */
	void enterCaso_defecto(PsicoderParser.Caso_defectoContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#caso_defecto}.
	 * @param ctx the parse tree
	 */
	void exitCaso_defecto(PsicoderParser.Caso_defectoContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#uno_o_mas_casos}.
	 * @param ctx the parse tree
	 */
	void enterUno_o_mas_casos(PsicoderParser.Uno_o_mas_casosContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#uno_o_mas_casos}.
	 * @param ctx the parse tree
	 */
	void exitUno_o_mas_casos(PsicoderParser.Uno_o_mas_casosContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#casos_2_a_n}.
	 * @param ctx the parse tree
	 */
	void enterCasos_2_a_n(PsicoderParser.Casos_2_a_nContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#casos_2_a_n}.
	 * @param ctx the parse tree
	 */
	void exitCasos_2_a_n(PsicoderParser.Casos_2_a_nContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#rompimiento}.
	 * @param ctx the parse tree
	 */
	void enterRompimiento(PsicoderParser.RompimientoContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#rompimiento}.
	 * @param ctx the parse tree
	 */
	void exitRompimiento(PsicoderParser.RompimientoContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#acciones_comando_seleccion}.
	 * @param ctx the parse tree
	 */
	void enterAcciones_comando_seleccion(PsicoderParser.Acciones_comando_seleccionContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#acciones_comando_seleccion}.
	 * @param ctx the parse tree
	 */
	void exitAcciones_comando_seleccion(PsicoderParser.Acciones_comando_seleccionContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#accion_seleccion}.
	 * @param ctx the parse tree
	 */
	void enterAccion_seleccion(PsicoderParser.Accion_seleccionContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#accion_seleccion}.
	 * @param ctx the parse tree
	 */
	void exitAccion_seleccion(PsicoderParser.Accion_seleccionContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#estructuras_y_funciones}.
	 * @param ctx the parse tree
	 */
	void enterEstructuras_y_funciones(PsicoderParser.Estructuras_y_funcionesContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#estructuras_y_funciones}.
	 * @param ctx the parse tree
	 */
	void exitEstructuras_y_funciones(PsicoderParser.Estructuras_y_funcionesContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#estructura_o_funcion}.
	 * @param ctx the parse tree
	 */
	void enterEstructura_o_funcion(PsicoderParser.Estructura_o_funcionContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#estructura_o_funcion}.
	 * @param ctx the parse tree
	 */
	void exitEstructura_o_funcion(PsicoderParser.Estructura_o_funcionContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#funcion_principal}.
	 * @param ctx the parse tree
	 */
	void enterFuncion_principal(PsicoderParser.Funcion_principalContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#funcion_principal}.
	 * @param ctx the parse tree
	 */
	void exitFuncion_principal(PsicoderParser.Funcion_principalContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#acciones_funcion_principal}.
	 * @param ctx the parse tree
	 */
	void enterAcciones_funcion_principal(PsicoderParser.Acciones_funcion_principalContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#acciones_funcion_principal}.
	 * @param ctx the parse tree
	 */
	void exitAcciones_funcion_principal(PsicoderParser.Acciones_funcion_principalContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#programa_en_psicoder}.
	 * @param ctx the parse tree
	 */
	void enterPrograma_en_psicoder(PsicoderParser.Programa_en_psicoderContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#programa_en_psicoder}.
	 * @param ctx the parse tree
	 */
	void exitPrograma_en_psicoder(PsicoderParser.Programa_en_psicoderContext ctx);
}